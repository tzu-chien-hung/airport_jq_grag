(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Untitled_1_atlas_1", frames: [[1978,285,46,48],[2026,285,22,22],[257,1268,125,128],[520,1273,125,128],[129,1268,126,127],[0,1266,127,126],[860,1261,126,128],[647,1274,125,128],[1486,1279,125,128],[1197,1282,125,128],[1169,0,324,345],[0,546,301,317],[1495,341,315,331],[303,546,301,316],[1495,0,322,339],[1169,347,305,321],[704,1115,154,157],[389,1075,156,157],[547,1115,155,156],[884,1102,155,157],[1330,1146,154,157],[1041,1148,154,157],[1197,1148,129,132],[1486,1146,130,131],[1618,1151,131,129],[1751,1151,129,131],[1882,1151,129,131],[389,1234,129,131],[1440,953,186,191],[1142,955,186,191],[1628,958,186,191],[1816,958,186,191],[201,1075,186,191],[606,546,276,283],[1812,341,236,280],[884,546,276,283],[884,831,256,269],[1723,674,276,282],[303,864,281,209],[1440,674,281,277],[0,865,199,283],[606,831,276,282],[1819,0,217,283],[1162,670,276,283],[0,0,1167,271],[2038,20,6,6],[2026,309,15,15],[2038,0,8,8],[1874,285,50,52],[0,273,1167,271],[2038,28,6,6],[1476,347,15,15],[2038,10,8,8],[2026,326,11,11],[1926,285,50,52],[1812,623,46,48],[1860,623,46,48],[201,865,78,80],[201,947,78,80],[1330,955,56,57],[1819,285,53,53],[1330,1014,56,57],[0,1150,180,114],[1908,623,42,20],[1952,623,41,19]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_67 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_65 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(img.CachedBmp_22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2068,1368);


(lib.CachedBmp_21 = function() {
	this.initialize(img.CachedBmp_21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2068,1368);


(lib.CachedBmp_20 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.TryTrySee = function() {
	this.initialize(img.TryTrySee);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4676,4676);


(lib.Mesh = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_1 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_0 = function() {
	this.initialize(ss["Untitled_1_atlas_1"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Path_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","#010201","#060907","#0F1410","#1B251C","#2B3B2D","#3F5742","#57775A","#729D77","#92C897","#B3F6BA","#BAFFC1"],[0,0.373,0.506,0.604,0.678,0.745,0.804,0.859,0.906,0.953,0.992,1],-0.3,0.7,0,-0.3,0.7,3.2).s().p("AgNATQgIgGgBgJQgCgJAGgIQAGgIAJgBQAJgCAIAGQAIAGABAJQACAJgGAIQgGAIgJABIgEABQgHAAgGgFg");
	this.shape.setTransform(2.3739,2.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(0,0,4.8,4.7), null);


(lib.Path = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#6E76DB","#757CDD","#888EE1","#A7ACE9","#D2D5F4","#FFFFFF"],[0,0.129,0.314,0.537,0.78,1],-1.2,1.5,0,-1.2,1.5,4.2).s().p("AgNATQgIgGgBgJQgCgJAGgIQAGgIAJgBQAJgCAIAGQAIAGABAJQACAJgGAIQgGAIgJABIgEABQgHAAgGgFg");
	this.shape.setTransform(2.3739,2.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,4.8,4.7), null);


(lib.Path_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","#FEFBFF","#FBEFFF","#F7DCFF","#F1C0FF","#EAA2FF"],[0,0.212,0.416,0.624,0.824,1],-2.2,4.4,0,-2.2,4.4,10.1).s().p("AgDA1QgJgBgHgDQgOgGgJgMQgFgGgCgIQgCgEgBgJIAAgCQAAgFABgGQACgIADgGQAIgRATgIQAKgEAIAAQAEAAAJACQALACAKAIQALAIAFAOQADAIABAJIAAAAQAAAHgCAIIgFAMQgPAagdABg");
	this.shape.setTransform(5.2688,5.27);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0,10.6,10.6), null);


(lib.Path_0_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#F7F7F7","#915EFF"],[0.271,1],-3.9,1.9,0,-3.9,1.9,9.7).s().p("AAtAhIgCgLIgBgDIAAAAIgIgOQgFgGgGgGIgBAAIgFgDQgHgFgIgCIgDgBQgHgCgKAAIgCAAQgJABgKAEIgJAEIAIgJIAIgGIADgCQALgGANAAQASgBAQAMQAOAMAFASIAAABIAAABIAAADIABABIAAADQAAAKgEAJg");
	this.shape_1.setTransform(4.85,3.524);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0_1, new cjs.Rectangle(0,0,9.7,7.1), null);


(lib.Path_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#000000","#010304","#060C11","#0D1A27","#182E45","#25486C","#35689B","#35689C"],[0.243,0.357,0.478,0.604,0.733,0.867,1,1],2.7,-3.5,0,2.7,-3.5,9.8).s().p("AgDA1QgJgBgHgDQgOgGgJgMQgFgGgCgIQgCgEgBgJIAAgCQAAgFABgGQACgIADgGQAIgRATgIQAKgEAIAAQAEAAAJACQALACAKAIQALAIAFAOQADAIABAJIAAAAQAAAHgCAIIgFAMQgPAagdABg");
	this.shape_1.setTransform(5.2688,5.27);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2, new cjs.Rectangle(0,0,10.6,10.6), null);


(lib.Group_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","#130818","#411B54","#662A84","#8035A6","#903CBA","#963EC2"],[0,0.09,0.325,0.545,0.737,0.894,1],2.9,-4.2,0,2.9,-4.2,10.5).s().p("AgqAhQgKgNgBgSQAAgIACgIQAFgUASgLQAKgGAOgCQAVgCARAOQASAOACAWQABAPgGAOQgJASgTAIQgKAEgJAAIgCAAQgbAAgPgVg");
	this.shape.setTransform(5.4141,5.3896);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,10.9,10.8), null);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EAF3F3").s().p("AhqA3QgHgNAcgZQAPgOATgMIAAACQgWAOgLALQgaAYAFAMQAGAKAXgDQAagDAggOQATgHAOgIQAVgLAUgNQAQgJANgNQAagYgFgNQgFgIgYACQgVACgXAJIgCgBQAagJAUgCQAZgDAFAKQAHANgcAZQgMAMgTALQgSAMgVAMIggAPQgjAOgZACIgJABQgQAAgFgIg");
	this.shape.setTransform(10.775,6.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,21.6,12.6), null);


(lib.Path_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,32).s().p("Aj6DHQgEgFBHg+QBHg+BnhRQBphUBLg2QBMg2AEAFQAEAFhGA+QhIA+hnBRQhnBThNA3QhGAygJAAIgBgBg");
	this.shape.setTransform(25.1251,19.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,50.3,40), null);


(lib.Path_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,32).s().p("ACEC5Qg+hIhRhnQhThng3hNQg2hMAFgEQAFgEA+BGQA+BHBRBoQBTBmA3BOQA3BMgGAEIAAAAQgIAAg7hCg");
	this.shape.setTransform(19.979,25.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14, new cjs.Rectangle(0,0,40,50.3), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,43.6).s().p("AExAyQh/gIizgVQizgUh/gUQh+gVAAgJQABgJCAAJQB/AICzAVQC0AUB+AUQB/AVgCAJQAAAEgiAAQggAAg+gEg");
	this.shape.setTransform(43.35,5.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,86.7,10.9), null);


(lib.Path_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,43.6).s().p("AmyAqQAAgJB+gTQB+gRC1gRQCygRCAgGQCAgGACAIQAAAJh+ATQh/ARi0ARQizARiAAGQg1ADgfAAQgsAAgBgFg");
	this.shape.setTransform(43.4503,4.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12, new cjs.Rectangle(0,0,86.9,9.4), null);


(lib.Path_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,33.9).s().p("AgmFRQgIgBAFhjQAFhlAQiJQAQiMARhiQARhiAJABQAJABgFBjQgGBjgQCLQgQCNgQBhQgSBhgJAAIAAAAg");
	this.shape.setTransform(4.4467,33.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11, new cjs.Rectangle(0,0,8.9,67.5), null);


(lib.Path_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,35.9).s().p("AAKD+QgQhogOiUQgPiUgEhoQgEhpAJgBQAIgBARBoQAQBpAOCTQAPCRAEBrQAEBqgIAAIAAAAQgJAAgRhng");
	this.shape.setTransform(4.1275,35.7254);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10, new cjs.Rectangle(0,0,8.3,71.5), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,36.1).s().p("ADXCLQhggyh/hKQiBhJhZg6Qhag5AEgGQAEgHBeAxQBfAwB/BLQCBBJBbA6QBYA5gDAHIgCAAQgMAAhUgqg");
	this.shape.setTransform(31.3,18.1449);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,62.6,36.3), null);


(lib.Path_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,36.1).s().p("Ai0E5QgGgEAxheQAwhfBKiAQBKiBA5hZQA6haAGAEQAHAEgwBeQgxBfhLCAQhJCBg6BaQg3BVgIAAIgBAAg");
	this.shape.setTransform(18.15,31.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0.1,36.3,62.5), null);


(lib.Path_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,27.8).s().p("AAqDBQgZhOgdhvQgehvgShQQgRhQAGgBQAFgCAZBOQAZBNAdBwQAeBvASBQQARBQgGABIAAAAQgGAAgYhMg");
	this.shape.setTransform(7.325,26.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7, new cjs.Rectangle(0,0,14.7,53.9), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,27.9).s().p("AkNBIQgBgFBOgZQBOgZBwgdQBugeBQgSQBQgRACAGQABAFhOAZQhOAZhwAdQhvAehPASQg8ANgQAAQgFAAgBgCg");
	this.shape.setTransform(26.95,7.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,53.9,14.8), null);


(lib.Path_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,31.8).s().p("AhoEtQgGgCAahaQAbhZArh8QArh+AjhVQAjhXAGACQAGACgaBaQgbBZgrB8QgrB9gjBWQgiBVgHAAIAAAAg");
	this.shape.setTransform(10.5914,30.0762);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,21.2,60.2), null);


(lib.Path_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,31.8).s().p("ADRBVQhZgah9gsQh8grhWgjQhXgjACgGQADgGBZAaQBZAbB8ArQB8ArBXAjQBXAjgCAGQAAAAAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgQAAhIgVg");
	this.shape.setTransform(30.1,10.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4, new cjs.Rectangle(0,0,60.2,21.2), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,39).s().p("AleCqQgEgHBkg3QBlg3CShFQCQhGBqgtQBpgtAEAHQADAHhkA3QhnA4iQBEQiQBGhqAtQhbAngPAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAAAAAAAg");
	this.shape.setTransform(35.2,17.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0.1,0,70.30000000000001,34.2), null);


(lib.Path_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,39).s().p("ABsD/Qg3hlhFiSQhHiRgshpQgthpAHgEQAHgDA3BlQA3BlBFCRQBGCQAtBqQAtBpgHAEIgBAAQgIAAg1hhg");
	this.shape.setTransform(17.025,35.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_1, new cjs.Rectangle(0,0,34.1,70.4), null);


(lib.Path_1_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F86868","#DE5D5D","#9A4040","#2E1313","#000000"],[0,0.133,0.42,0.831,1],0,0,0,0,0,26.1).s().p("AgdEDQhrgMhEhVQhDhUANhrQAMhrBVhEQBVhDBqANQBsAMBDBVQBDBUgMBrQgMBshVBDQhIA4hYAAQgPAAgRgCg");
	this.shape.setTransform(26.1494,26.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_0, new cjs.Rectangle(0,0,52.3,52.3), null);


(lib.Path_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,47.3).s().p("ADvDrQhshXiRiDQiSiAhjhiQhjhiAGgHQAHgHBsBXQBsBYCRCCQCRCABjBiQBjBigGAHIgCAAQgNAAhjhQg");
	this.shape_1.setTransform(35.325,31.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_1, new cjs.Rectangle(0,0,70.7,63.1), null);


(lib.Path_0_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,0,0,0)","rgba(103,71,31,0)","#67471F","#422E14","#251A0B","#100B05","#040301","#000000"],[0,0.631,0.631,0.667,0.706,0.741,0.776,0.812],0,0,0,0,0,23.3).s().p("AgaDpQhggMg8hMQg9hLAMhgQALhgBMg8QBMg9BfAMQBgALA8BMQA9BLgLBgQgLBghMA8QhBAzhPAAQgNAAgPgBg");
	this.shape_2.setTransform(23.3928,23.4428);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#421E0B","#47220C","#A46C17","#DE9B1D","#F5AD20","#F8F8F8","#F8F8A6","#D9D288","#AC995C","#8B703C","#775628","#6F4D21","#67471F","rgba(103,71,31,0)","rgba(0,0,0,0)"],[0,0.008,0.157,0.259,0.31,0.471,0.518,0.533,0.565,0.592,0.612,0.624,0.631,0.631,1],0,0,0,0,0,23.3).s().p("AgaDpQhggMg8hMQg9hLAMhgQALhgBMg8QBMg9BfAMQBgALA8BMQA9BLgLBgQgLBghMA8QhBAzhPAAQgNAAgPgBg");
	this.shape_3.setTransform(23.3928,23.4428);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0_2, new cjs.Rectangle(0,0,46.8,46.9), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#F8AA02","#CB8B02","#A16E01","#7A5401","#593D01","#3D2A00","#271A00","#150E00","#090600","#020100","#000000"],[0,0.043,0.09,0.145,0.2,0.267,0.337,0.42,0.518,0.655,1],0,0,0,0,0,47.2).s().p("Ak5FhQgIgHBXhrQBXhsCDiRQCBiTBhhiQBihjAHAGQAHAHhXBsQhYBsiCCQQiBCShhBjQhbBdgMAAIgBAAg");
	this.shape_2.setTransform(31.4963,35.325);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,63,70.7), null);


(lib.Group_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F8B200","#DE9F00","#9A6E00","#2E2100","#000000"],[0,0.133,0.42,0.831,1],0.3,0.5,0,0.3,0.5,17.7).s().p("AAPCbIgMgSQgBAFgFAQIgKgSQgEAKgNALIgPALQADgLgBgYIgJAFQgFACgBADQgCgFABgKIABgJQgHABgLALQgMAKACAKQgIgLACgVIAEgUQgHAFgLABIgPABQABgGAHgGIAHgFIgWAAQgMABgDAHQgDgMAMgPIAMgMQgGABgJgEQgJgDgFAAQACgDAIgHIAJgGQgMADgNgGQgKgEgHgIQAFABAQgGIATgJQgCgEgHgEQgHgDgGAAQACgDAIgFIAHgFQgSgCgSgRQAEACAVgFQAYgFAEgBQgHgFgLgWQAGADANgCQgQgWgOAAQAGgIASABQASAAAKAHQgHgJgEgKIgCgIQAIAGARADQAFgYgLgNIAQAKQAOAJAGABIABgWIAOAPQAJgeAIgQQgBAJAYAiQADgDAGgIIAGgLQADAHAAAFQAEgHALgHQAKgHAGgBQgEAEAAAOIgCASQAJABAFgKQAEAGgFAQQAKgDAegZQADAPgMAUQAIgCALADQgEACgEAEIgDAFQASgGAhAFQgEABgMAOIgOAQQAMADAMAGQgEACgFAFIgEAEQAIAAAPAGQANAEAFAFQgFAAgLAIQgMAIgDACQAGAAAIAHIAKAIIgPACIgOADQAfAWAPgHQgLALggAJQANAKAHAPQgEgFgLAAIgPAAQAMALANAaQgGgCgPgCQgPgDgEgBQABAHAGAIQAGAHAGADQgGACgNgEQgNgEgFgEQAKAQgBAlQgGgKgPgKIgPgJQAEAMgFARQgDgIgHgIQgIgIgBgDQgIAkgNALQACgHgJgPg");
	this.shape.setTransform(17.625,17.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_16, new cjs.Rectangle(0,0,35.3,35.5), null);


(lib.Group_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFEAB").s().p("AgRBuQgigSgTgfIAAgBQgKgRgEgVIgCgQIAAgPQAEgrAeggQAagcAjgGIASgCQAfgBAdAQQgfAGgZATQgaAVgKAdQgPAlASAqQAQApApAdIgMACIgLAAQgaAAgXgLg");
	this.shape.setTransform(8.7125,12.1257);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,17.4,24.3), null);


(lib.Group_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFEAB").s().p("AgQA2QgTggAFgeQAFgfAagYQAZgVAGAFQABABgNAXQgQAegEAdQgCAaAGAcQAEAWgBAAIgCABQgGAAgPgbg");
	this.shape_1.setTransform(3.2016,8.008);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(0,0,6.4,16.1), null);


(lib.Path_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#000000","#020201","#080906","#14140F","#25251B","#3A3B2B","#55573E","#747756","#989B70","#AFB381"],[0.576,0.745,0.808,0.851,0.886,0.918,0.941,0.969,0.988,1],5.3,1.1,0,5.3,1.1,12.1).s().p("AgYA8QgKgFgFgEQgFgEgGgHIgBgCQgEgFgEgJQgEgJgBgKQgBgSAJgRQAEgIAIgIIAFgEQANgLASgCQAPgDAQAGIAOAHQAIAGAGAHQAIAKACAJQAGARgDAQQgDAPgIALQgEAFgIAIQgJAGgLAEQgLAEgKAAQgMAAgMgFg");
	this.shape_1.setTransform(6.4893,6.5064);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_2, new cjs.Rectangle(0,0,13,13), null);


(lib.Path_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#F7F7F7","#E3A1FF"],[0.271,1],-6.1,2,0,-6.1,2,12.2).s().p("AgpA8QAJgBAGgDIABAAQAMgEAKgHQAHgIAFgHQAJgMAEgQQAEgSgIgTQgCgJgJgLIAAAAIgGgHQAJAEAEADQAIAGAGAHQAHAKADAJQAGARgDAQQgDAPgJALQgDAFgJAIQgIAGgKAEQgLAEgKAAQgJAAgKgDg");
	this.shape_2.setTransform(4.2,6.2815);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_2, new cjs.Rectangle(0,0,8.4,12.6), null);


(lib.Path_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFFFF","#FEFBFF","#FBEFFF","#F7DCFF","#F1C0FF","#EAA2FF"],[0,0.212,0.416,0.624,0.824,1],-5.4,-2.1,0,-5.4,-2.1,11.9).s().p("AgXA6QgIgDgHgFQgGgFgEgGIgCgCIgHgNQgEgJgBgJQgBgRAIgRQAEgHAIgJIAFgEQAcgWAgAMIAOAIQAIAFAFAHQAGAHAEALQAGAQgDAQQgCANgJAMQgEAGgIAHQgJAHgKADQgKADgKAAQgLAAgMgFg");
	this.shape_3.setTransform(6.2667,6.2722);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17, new cjs.Rectangle(0,0,12.6,12.6), null);


(lib.Group_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#521223","#581429","#681B38","#832553","#A93477","#C23E8F","#C14F8E","#BF7B8C","#BDAF8A"],[0,0.09,0.208,0.337,0.482,0.565,0.651,0.82,1],6.5,1.9,0,6.5,1.9,13.5).s().p("AgbA/QgRgIgMgQQgQgYAFgaQAFgcAXgQQAMgJARgCQAZgEAWAOQAJAGAHAJQAOASAAAUQAEgCgFAVQgGAXgSAPQgKAHgMAEQgLADgJAAQgOAAgNgFg");
	this.shape_1.setTransform(6.9139,6.8425);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_1, new cjs.Rectangle(0,0,13.8,13.7), null);


(lib.Group_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoAzQglgQgCgZQgBgbApgXQAqgVA5gEIAUgBQA2AAAjAQQAmAQABAaQABAagpAWQgpAXg7ADIgTABQg2AAgjgQgAgDg+Qg7AEgoAVQgoAVACAaQACAXAjAQQAkAPA0AAIATAAQA6gEApgWQAogVgCgZQgBgYgkgPQgkgQg0AAg");
	this.shape_2.setTransform(14.4,6.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(0,0,28.8,13.4), null);


(lib.Path_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#A3470F","#A44811","#A84E18","#AE5623","#B76334","#C3744A","#D28866","#E3A186","#F6BCAA","#FFC8BA"],[0,0.404,0.549,0.651,0.737,0.808,0.871,0.929,0.98,1],1.6,-0.9,0,1.6,-0.9,4).s().p("AgUADIAAgEIACgGIAAgBQACgEAFgEIAEgCIABgBIAGgBIACAAIAHACIAAABIAFAEIABAAQAGAHgBAGIAAACIAAAEQgDAHgGAEIAAAAIgFACIAAABIgBAAIgIABQgOgDgDgPg");
	this.shape_1.setTransform(2.0519,2.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_1, new cjs.Rectangle(0,0,4.1,4.1), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#000000","#020101","#090706","#14100F","#251D1B","#3B2F2B","#57443F","#775D57","#9D7B72","#C89D92","#F6C1B3","#FFC8BA"],[0,0.373,0.506,0.604,0.678,0.745,0.804,0.859,0.906,0.953,0.992,1],1.5,-0.9,0,1.5,-0.9,3.8).s().p("AgBATIgBAAQgPgCgCgOIAAgEIACgGIAAAAQADgGADgCIAEgCIABgBIAGgBIACAAIAHACIAFAEIAAAAQAGAGgBAHIAAACIAAADQgCAHgGAEIgBABIgEABIgBABIAAAAIgFABIgBgBg");
	this.shape_4.setTransform(1.9519,1.9583);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,3.9,3.9), null);


(lib.Group_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_67();
	this.instance.setTransform(0,0,0.0824,0.0824);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_2, new cjs.Rectangle(0,0,3.8,4), null);


(lib.Group_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#D67F52","#CB6F45","#B14725"],[0,0.353,1],-0.8,0.2,0,-0.8,0.2,2.2).s().p("AABATQAIgFAAgJQABgHgGgGQgEgGgHgBIgIABIAEgDIABAAIAHgBIACAAIAGACIAFADIAAABQAGAFgBAIIAAABIAAADQgDAIgFAEIgBAAIgEACIAAAAg");
	this.shape_3.setTransform(1.55,1.925);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,3.1,3.9), null);


(lib.Path_3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#041F30","#071E2C","#0E1B1F","#121A19"],[0,0.416,0.843,1],3.9,3.1,0,3.9,3.1,10.9).s().p("AgRA2QgPgFgLgNIgFgHIgEgJIgCgGIAAgBQgCgKAAgIIADgMIABgEQAFgKAFgFIAEgEIAIgHQAIgFAJgCQAPgFAQAGIAMAFIADACQAIAGAEAFQAHAJADAMIAAABIABADIABAJIAAAJIgBAFIgDAJIgEAIQgMATgWAGQgIACgHAAQgIAAgJgDg");
	this.shape_2.setTransform(5.695,5.7126);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_2, new cjs.Rectangle(0,0,11.4,11.5), null);


(lib.Path_1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#404D80","#495A89","#89B9C9","#A3DEE2","#BAE6E9","#ECF8F9","#FFFFFF"],[0,0.067,0.549,0.769,0.82,0.941,1],2.3,5.1,0,2.3,5.1,9.4).s().p("AgsAmQAMADAMgDQAXgGAMgVQAMgTgGgYQgDgKgHgJIAIADIADADQAHAFAEAFQAHAJADAKIAAABIACAMIAAAIIgBAGIgDAIIgEAHQgMATgVAFQgHACgHAAQgTAAgPgOg");
	this.shape_3.setTransform(4.525,5.2393);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_3, new cjs.Rectangle(0,0,9.1,10.5), null);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#000000","#010202","#060908","#0F1414","#1B2525","#2B3B3A","#3F5755","#577774","#729D99","#92C8C3","#B3F6F0","#BAFFF9"],[0,0.373,0.506,0.604,0.678,0.745,0.804,0.859,0.906,0.953,0.992,1],2,4.3,0,2,4.3,10.4).s().p("AgKA1QgQgEgLgLQgMgLgDgPIgBgIIAAgJIABgGIAAgBQACgIAFgIIAHgJIADgDQAIgGAHgDIAPgEQAHgBAJACQAQADALALIAIAKIACAEQADAGACAIQADAKgDAKIAAABIgBAEIgDAIIgFAIIgCAEIgOALQgNAIgOAAIgLgBg");
	this.shape_5.setTransform(5.45,5.4195);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,10.9,10.9), null);


(lib.CompoundPath_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#F6FCFF","#BCE5FF","#98D7FF","#8AD2FF"],[0,0.063,0.502,0.827,1],-0.3,5.4,0.4,-5.6).s().p("AicApQgDgGAdgNQAcgMAugNIAAABQgrAMgbAMQgaAMABAFQACAGAdgDQAcgDAtgJQAfgHAVgGQAXgFAdgJQAsgNAZgLQAagMgBgFQgBgGgdADQgcACgtAKIgBgBQAwgLAegCQAfgDACAGQABAGgcANQgcAMguANIg0APIg0AMQgvAKgeADIgRABQgOAAgBgEg");
	this.shape.setTransform(15.8,4.5026);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CompoundPath_5, new cjs.Rectangle(0.1,0,31.5,9), null);


(lib.CompoundPath_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#F6FCFF","#BCE5FF","#98D7FF","#8AD2FF"],[0,0.063,0.502,0.827,1],-0.3,5.6,0.4,-5.7).s().p("AiWAnQgCgFAbgMQAagMArgMIAAAHIABADIAAABQgOAGAAADQABADAQgCQATgBAjgJQAjgJAUgIQAOgGgBgDQgBgDgPABIgBgBIgBgDIgBgBIAAgCIgBgBIgBgCQAsgKAcgCQAdgDABAGQACAFgbAMQgZALgsANQgdAJgXAFQgVAGgfAHQgtAJgcADIgPABQgOAAgBgEg");
	this.shape.setTransform(15.125,4.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CompoundPath_4, new cjs.Rectangle(0,0,30.3,8.6), null);


(lib.CompoundPath_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#F6FCFF","#BCE5FF","#98D7FF","#8AD2FF"],[0,0.063,0.502,0.827,1],-0.3,5.4,0.4,-5.6).s().p("AiBAhQgBgEAUgKQAUgJAigKIAAABQhCAVACAJQADAJBDgNQAVgEAggJQAhgIAVgGQBCgVgDgJQgBgEgTABQgUABgeAGIgBgBQAkgHAVgCQAWgBACAEQACALhLAWQgUAHghAJIg1AMQguAJgUAAQgNAAgBgEg");
	this.shape.setTransform(13.0017,3.7313);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CompoundPath_3, new cjs.Rectangle(0,0,26,7.5), null);


(lib.CompoundPath_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#F6FCFF","#BCE5FF","#98D7FF","#8AD2FF"],[0,0.063,0.502,0.827,1],-0.3,5.5,0.4,-5.7).s().p("Ah4AfQgCgJBCgVIAAAEIAAADQgUAIACADQABAEAUgDQAVgCAjgJQAdgHAZgJQATgIgBgEQgBgDgVACIgBgDIgBgBIAAgCQAegGATgBQATgBACAEQACAJhCAVQgUAGghAIQghAJgUAEQgpAIgRAAQgMAAgBgEg");
	this.shape.setTransform(12.05,3.445);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CompoundPath_2, new cjs.Rectangle(0,0,24.1,6.9), null);


(lib.CompoundPath_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#F6FCFF","#BCE5FF","#98D7FF","#8AD2FF"],[0,0.063,0.502,0.827,1],-0.3,5,0.3,-5.5).s().p("AhiAaQgCgHAsgQIAAACQgmANABAGQACAGAogHQAagEAcgIQAYgGAegJQAngOgCgFQgBgGgpAGIgBgBQAvgIABAHQACAIgsAPQgTAGgiAJQgaAHgcAFQgYAEgMAAQgLAAgBgDg");
	this.shape.setTransform(9.8982,2.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CompoundPath_1, new cjs.Rectangle(0,0,19.8,5.8), null);


(lib.CompoundPath = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#F6FCFF","#BCE5FF","#98D7FF","#8AD2FF"],[0,0.063,0.502,0.827,1],-0.3,5.5,0.4,-6).s().p("AhdAYQgCgGAngNIABADIAAABQgOAGAAADQABADAPgCQAUgBAjgJQAigJAUgIQAOgGAAgDQgBgDgPABIgBgBIgBgDQApgGABAGQACAFgnAOQgeAJgYAGQgcAIgaAEQgWAEgKAAQgJAAgBgDg");
	this.shape.setTransform(9.4,2.657);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CompoundPath, new cjs.Rectangle(0,0,18.8,5.4), null);


(lib.Path_1_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#8E29D1","#AC63DD","#D0A5EC","#E9D6F6","#F9F4FD","#FFFFFF"],[0,0.22,0.494,0.725,0.902,1],0.9,8,-1.3,-7.5).s().p("AgdBHQgVgGgOgQQAPACARgEQAdgJAOgbQAPgbgJgdQgFgQgLgMQAWADAQAOQARAOAGAVQAJAdgPAbQgPAbgdAJQgLADgJAAQgLAAgKgDg");
	this.shape_4.setTransform(6.5321,7.4375);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_4, new cjs.Rectangle(0,0,13.1,14.9), null);


(lib.Path_20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#412EC7","#3B2AB5","#291D7F","#1B1351","#0F0B2E","#070515","#020105","#000000"],[0,0.055,0.235,0.412,0.584,0.741,0.886,1],-4.1,-2.4,0,-4.1,-2.4,11.2).s().p("AgVBHQgKgDgIgGIgEgCIgIgHQgHgHgHgLIgHgUIgBgFQgBgIABgHIAAgEQABgJADgIIADgGQAFgLAKgJIADgEQAMgKAQgFQAPgEAOACIAIABQALADAIAEIAGAEQAJAGAIAKIAEAFIAGALIADAIIAAABIACAMIABAGQAAAMgEALIgBAFIgEAIIgBADQgKARgQAJQgIAFgKADQgLAEgKAAQgKAAgLgEg");
	this.shape_6.setTransform(7.48,7.5007);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_20, new cjs.Rectangle(0,0.1,15,14.9), null);


(lib.Path_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#000000","#030302","#0E0D0A","#1F1E16","#383527","#58543E","#807959","#AEA57A","#E3D69E","#FFF1B2"],[0.635,0.69,0.737,0.78,0.824,0.867,0.906,0.945,0.98,1],-2.4,-0.7,0,-2.4,-0.7,6.4).s().p("AgMAgQgNgFgFgOQgGgNAFgMQAGgNANgFQAMgGANAFQANAGAFANQAGAMgFANQgFANgOAFQgHADgGAAQgGAAgGgCg");
	this.shape_2.setTransform(3.4375,3.4375);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_3, new cjs.Rectangle(0,0,6.9,6.9), null);


(lib.Path_1_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#000000","#030302","#0E0D0A","#1F1E16","#383527","#58543E","#807959","#AEA57A","#E3D69E","#FFF1B2"],[0.635,0.69,0.737,0.78,0.824,0.867,0.906,0.945,0.98,1],-0.6,-0.5,0,-0.6,-0.5,1.9).s().p("AgHAHQgCgDgBgEQABgEADgDQADgCADgBQAFABACADQADADAAADQAAAFgDACQgEADgDAAQgEAAgDgDg");
	this.shape_5.setTransform(1.05,1.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_5, new cjs.Rectangle(0,0,2.1,2.1), null);


(lib.Path_0_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#000000","#010202","#060908","#0F1414","#1B2525","#2B3B3A","#3F5755","#577774","#729D99","#92C8C3","#B3F6F0","#BAFFF9"],[0,0.373,0.506,0.604,0.678,0.745,0.804,0.859,0.906,0.953,0.992,1],3.2,2,0,3.2,2,15.8).s().p("AgtBrQgtgTgRgtQgSgsATgsQATgtAtgRQAsgSAsATQAsAUATAsQARAtgTArQgTAtgtASQgWAIgVAAQgXAAgWgKg");
	this.shape_4.setTransform(11.65,11.65);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0_3, new cjs.Rectangle(0,0,23.4,23.4), null);


(lib.Path_21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#996EDB","#9E75DD","#AB88E1","#C1A7E9","#DFD2F4","#FFFFFF"],[0,0.129,0.314,0.537,0.78,1],9.3,3.3,0,9.3,3.3,20.8).s().p("AgtBrQgtgTgRgtQgSgsATgsQATgtAtgRQAsgSAsATQAsAUATAsQARAtgTArQgTAtgtASQgWAIgVAAQgXAAgWgKg");
	this.shape_7.setTransform(11.65,11.65);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_21, new cjs.Rectangle(0,0,23.4,23.4), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjZBfQgUgxAVgwQAVgxAygTQAFgCAMACIAZAFQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgCADQgRAYgDAdQgEAdALAcIAEAJQAugIA+gXQBLgbAggbIgDgIQgMgegZgUQgZgTgfgEIAAAAQAUgeANgFQAxgTAxAVQAxAVAUAyIAWA5ImmCmg");
	mask.setTransform(22.7056,15.2613);

	// Layer_3
	this.instance = new lib.Mesh_0();
	this.instance.setTransform(1.1,6.3);

	this.instance_1 = new lib.Mesh_1();
	this.instance_1.setTransform(1,6.25);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(1,6.3,42,20), null);


(lib.Path_13_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFAAQgEAAAAgFg");
	this.shape_1.setTransform(0.525,0.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13_1, new cjs.Rectangle(0,0,1.1,1.1), null);


(lib.Path_12_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgIAAQAAgDACgDQADgCADAAQAJAAAAAIQAAAJgJAAQgIAAAAgJg");
	this.shape_1.setTransform(0.925,0.925);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12_1, new cjs.Rectangle(0,0,1.9,1.9), null);


(lib.Path_11_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFB082","#FDAD81","#F5A47D","#E99575","#D87F6B","#C1625F","#A5404F","#85173C","#750333"],[0,0.22,0.376,0.51,0.631,0.745,0.855,0.957,1],0,0,0,0,0,1).s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_1.setTransform(1,1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11_1, new cjs.Rectangle(0,0,2,2), null);


(lib.Path_10_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFB082","#FDAD81","#F5A47D","#E99575","#D87F6B","#C1625F","#A5404F","#85173C","#750333"],[0,0.22,0.376,0.51,0.631,0.745,0.855,0.957,1],0,0,0,0,0,1.8).s().p("AgLANQgGgGAAgHQAAgGAGgFQAFgGAGAAQAHAAAGAGQAFAFAAAGQAAAHgFAGQgGAFgHAAQgGAAgFgFg");
	this.shape_1.setTransform(1.775,1.775);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10_1, new cjs.Rectangle(0,0,3.6,3.6), null);


(lib.Path_9_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFB0DD","#FFB0DD","#F3A7D2","#B37C9B","#7D566C","#503745","#2D1F27","#140E12","#050405","#000000"],[0,0.553,0.569,0.639,0.71,0.776,0.839,0.898,0.957,1],0,0,0,0,0,0.4).s().p("AgDAAQAAgDADAAQAEAAAAADQAAAEgEAAQgDAAAAgEg");
	this.shape_1.setTransform(0.425,0.425);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_1, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.Path_8_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0)","rgba(160,197,255,0)","#A0C5FF","#87B6FF","#78ADFF","#73AAFF"],[0,0.812,0.812,0.882,0.945,1],0,0,0,0,0,1.1).s().p("AgGAIQgEgEAAgEQAAgDAEgDQADgEADAAQAFAAADAEQADADAAADQAAAEgDAEQgDADgFAAQgDAAgDgDg");
	this.shape_1.setTransform(1.1,1.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#001D4A","#021F4C","#092552","#14305C","#25406A","#3B557D","#576F95","#778EB1","#9DB2D2","#C6D8F5","#D1E3FF","#C2DAFF","#A0C5FF","rgba(160,197,255,0)","rgba(0,0,0,0)"],[0,0.275,0.373,0.443,0.502,0.549,0.592,0.631,0.671,0.702,0.71,0.737,0.812,0.812,1],0,0,0,0,0,1.1).s().p("AgGAIQgEgEAAgEQAAgDAEgDQADgEADAAQAFAAADAEQADADAAADQAAAEgDAEQgDADgFAAQgDAAgDgDg");
	this.shape_2.setTransform(1.1,1.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_1, new cjs.Rectangle(0,0,2.2,2.2), null);


(lib.Path_7_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0)","rgba(160,197,255,0)","#A0C5FF","#87B6FF","#78ADFF","#73AAFF"],[0,0.812,0.812,0.882,0.945,1],0,0,0,0,0,1.5).s().p("AgKALQgEgFAAgGQAAgFAEgFQAEgEAGAAQAGAAAEAEQAFAFAAAFQAAAGgFAFQgEAEgGAAQgGAAgEgEg");
	this.shape_1.setTransform(1.5,1.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#001D4A","#021F4C","#092552","#14305C","#25406A","#3B557D","#576F95","#778EB1","#9DB2D2","#C6D8F5","#D1E3FF","#C2DAFF","#A0C5FF","rgba(160,197,255,0)","rgba(0,0,0,0)"],[0,0.275,0.373,0.443,0.502,0.549,0.592,0.631,0.671,0.702,0.71,0.737,0.812,0.812,1],0,0,0,0,0,1.5).s().p("AgKALQgEgFAAgGQAAgFAEgFQAEgEAGAAQAGAAAEAEQAFAFAAAFQAAAGgFAFQgEAEgGAAQgGAAgEgEg");
	this.shape_2.setTransform(1.5,1.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7_1, new cjs.Rectangle(0,0,3,3.1), null);


(lib.Path_6_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFF391","#FFF391","#F3E78A","#B3AB66","#7D7747","#504C2D","#2D2B1A","#14130C","#050503","#000000"],[0,0.553,0.569,0.639,0.71,0.776,0.839,0.898,0.957,1],0,0,0,0,0,0.5).s().p("AgEAAQAAgEAEgBQAFABAAAEQAAAGgFgBQgEABAAgGg");
	this.shape_1.setTransform(0.525,0.55);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6_1, new cjs.Rectangle(0,0,1.1,1.1), null);


(lib.Path_5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0)","rgba(160,197,255,0)","#A0C5FF","#87B6FF","#78ADFF","#73AAFF"],[0,0.812,0.812,0.882,0.945,1],0,0,0,0,0,1.3).s().p("AgJAKQgEgFAAgFQAAgEAEgFQAFgEAEAAQAFAAAFAEQADAFABAEQgBAFgDAFQgFADgFABQgEgBgFgDg");
	this.shape_1.setTransform(1.35,1.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#001D4A","#021F4C","#092552","#14305C","#25406A","#3B557D","#576F95","#778EB1","#9DB2D2","#C6D8F5","#D1E3FF","#C2DAFF","#A0C5FF","rgba(160,197,255,0)","rgba(0,0,0,0)"],[0,0.275,0.373,0.443,0.502,0.549,0.592,0.631,0.671,0.702,0.71,0.737,0.812,0.812,1],0,0,0,0,0,1.3).s().p("AgJAKQgEgFAAgFQAAgEAEgFQAFgEAEAAQAFAAAFAEQADAFABAEQgBAFgDAFQgFADgFABQgEgBgFgDg");
	this.shape_2.setTransform(1.35,1.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5_1, new cjs.Rectangle(0,0,2.7,2.7), null);


(lib.Path_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0)","rgba(160,197,255,0)","#A0C5FF","#87B6FF","#78ADFF","#73AAFF"],[0,0.812,0.812,0.882,0.945,1],0,0,0,0,0,1.9).s().p("AgMANQgGgFAAgIQAAgHAGgFQAFgFAHgBQAIABAFAFQAGAFAAAHQAAAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_1.setTransform(1.875,1.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#001D4A","#021F4C","#092552","#14305C","#25406A","#3B557D","#576F95","#778EB1","#9DB2D2","#C6D8F5","#D1E3FF","#C2DAFF","#A0C5FF","rgba(160,197,255,0)","rgba(0,0,0,0)"],[0,0.275,0.373,0.443,0.502,0.549,0.592,0.631,0.671,0.702,0.71,0.737,0.812,0.812,1],0,0,0,0,0,1.9).s().p("AgMANQgGgFAAgIQAAgHAGgFQAFgFAHgBQAIABAFAFQAGAFAAAHQAAAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_2.setTransform(1.875,1.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4_1, new cjs.Rectangle(0,0,3.8,3.7), null);


(lib.Path_3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#A1FFCA","#8EE1B2","#71B28D","#56886B","#3F634E","#2B4436","#1B2B22","#0F1813","#060A08","#010202","#000000"],[0.467,0.486,0.518,0.557,0.592,0.635,0.682,0.729,0.788,0.863,1],0,0,0,0,0,0.5).s().p("AgEAAQABgDADgBQAEABAAADQAAAEgEAAQgDAAgBgEg");
	this.shape_3.setTransform(0.45,0.45);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_3, new cjs.Rectangle(0,0,0.9,0.9), null);


(lib.Path_2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_66();
	this.instance.setTransform(0,0,0.0824,0.0824);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2_4, new cjs.Rectangle(0,0,1.8,1.8), null);


(lib.Path_1_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#36FFBC","#36F4C5","#36D8DE","#36B2FF"],[0,0.216,0.592,1],0,0,0,0,0,2.4).s().p("AgQARQgHgHAAgKQAAgJAHgHQAHgHAJAAQAKAAAHAHQAHAHAAAJQAAAKgHAHQgHAHgKAAQgJAAgHgHg");
	this.shape_6.setTransform(2.4,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_6, new cjs.Rectangle(0,0,4.8,4.8), null);


(lib.Path_0_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0)","rgba(160,197,255,0)","#A0C5FF","#87B6FF","#78ADFF","#73AAFF"],[0,0.812,0.812,0.882,0.945,1],0,0,0,0,0,2.4).s().p("AgQARQgHgHAAgKQAAgJAHgHQAHgHAJAAQAKAAAHAHQAHAHAAAJQAAAKgHAHQgHAHgKAAQgJAAgHgHg");
	this.shape_5.setTransform(2.4,2.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#001D4A","#021F4C","#092552","#14305C","#25406A","#3B557D","#576F95","#778EB1","#9DB2D2","#C6D8F5","#D1E3FF","#C2DAFF","#A0C5FF","rgba(160,197,255,0)","rgba(0,0,0,0)"],[0,0.275,0.373,0.443,0.502,0.549,0.592,0.631,0.671,0.702,0.71,0.737,0.812,0.812,1],0,0,0,0,0,2.4).s().p("AgQARQgHgHAAgKQAAgJAHgHQAHgHAJAAQAKAAAHAHQAHAHAAAJQAAAKgHAHQgHAHgKAAQgJAAgHgHg");
	this.shape_6.setTransform(2.4,2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0_4, new cjs.Rectangle(0,0,4.8,4.8), null);


(lib.Path_22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(0,0,0,0)","rgba(160,197,255,0)","#A0C5FF","#87B6FF","#78ADFF","#73AAFF"],[0,0.812,0.812,0.882,0.945,1],0,0,0,0,0,1.2).s().p("AgHAIQgEgDAAgFQAAgEAEgDQADgEAEAAQAGAAADAEQADADAAAEQAAAFgDADQgEAEgFAAQgEAAgDgEg");
	this.shape_8.setTransform(1.2,1.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["#001D4A","#021F4C","#092552","#14305C","#25406A","#3B557D","#576F95","#778EB1","#9DB2D2","#C6D8F5","#D1E3FF","#C2DAFF","#A0C5FF","rgba(160,197,255,0)","rgba(0,0,0,0)"],[0,0.275,0.373,0.443,0.502,0.549,0.592,0.631,0.671,0.702,0.71,0.737,0.812,0.812,1],0,0,0,0,0,1.2).s().p("AgHAIQgEgDAAgFQAAgEAEgDQADgEAEAAQAGAAADAEQADADAAAEQAAAFgDADQgEAEgFAAQgEAAgDgEg");
	this.shape_9.setTransform(1.2,1.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_22, new cjs.Rectangle(0,0,2.4,2.4), null);


(lib.Group_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AB/HFQEvh8DEipQB5hoA2hmQA2hqgchXQgghliKg3QiFg2jMAAQiWAAinAdQimAdisA4QkdBdjbCKIAAgEQAzggA/giQC0hfDRhFQCsg4CsgeQClgcCTAAQDMAACGA2QBFAcAqAmQAsAoARA0QAdBYg3BrQg1Blh7BrQh8BrisBbQhgAzhkApg");
	this.shape_1.setTransform(84.0114,45.325);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_1, new cjs.Rectangle(0,0,168,90.7), null);


(lib.Group_1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AACGXIAIgCQCpg3CShNQCShOBnhaQBlhXArhUQAthZgYhIQgbhVhzgvQhwgtiqAAQj7AAkeBeQibAyiHBFQiIBFhlBRIAAgEQBYhGB1g/QCVhPCsg4QCPguCLgYQCFgXB7AAQCrAABwAtQA3AWAlAiQAmAiAOArQAXBKgtBZQgqBUhmBYQhlBYiQBNQiTBPitA4g");
	this.shape_2.setTransform(75.0031,40.725);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_3, new cjs.Rectangle(0,0,150,81.5), null);


(lib.Group_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AotFAQgtgSgbgaQgRgQgKgQIAAgGQAbAyBKAeQBYAkCFAAQDCgBDdhHQERhZCmiRQCmiQgmh1QgWhDhaglQhXgkiHAAQjCAAjdBIQjPBDiZBrQiVBmguBoIAAgHIACgGQAihDBOhEQBRhGBxg8QByg+CEgrQDdhHDDgBQCHAABYAkQArASAeAbQAeAbAKAiQATA8gjBFQgiBEhOBCQhQBHhyA9QhyA9iEAqQjdBIjDAAQiGABhZglg");
	this.shape.setTransform(65.7093,35.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(0,0,131.4,71.3), null);


(lib.Group_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AlpDRQg7gYgOgsQgMgkAWgtQAWgsA1gtQA2guBKgoQBLgnBXgdQCUgwCBAAQBXAAA5AXQA7AYAOAsQAMAkgWAtQgWAsg1AtQg1AuhLAoQhLAnhXAdQiUAwiCAAQhWAAg5gXgAg6i0QhWAchLAoQhLAng1AuQgzArgXAsQgWAsALAlQAPAqA5AXQA4AXBWAAQCAAACVgwQCzg6BthfQBuhdgYhLQgPgqg5gXQg3gXhYAAQiBAAiTAwg");
	this.shape_4.setTransform(43.925,23.175);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,87.9,46.4), null);


(lib.Tween86 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.TryTrySee();
	this.instance.setTransform(-51.95,-51.95,0.0222,0.0222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.9,-51.9,103.9,103.9);


(lib.Tween85 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.TryTrySee();
	this.instance.setTransform(-51.95,-51.95,0.0222,0.0222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.9,-51.9,103.9,103.9);


(lib.Tween84 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.TryTrySee();
	this.instance.setTransform(-51.95,-51.95,0.0222,0.0222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.9,-51.9,103.9,103.9);


(lib.Tween83 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.TryTrySee();
	this.instance.setTransform(-51.95,-51.95,0.0222,0.0222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.9,-51.9,103.9,103.9);


(lib.Tween82 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.TryTrySee();
	this.instance.setTransform(-51.95,-51.95,0.0222,0.0222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.9,-51.9,103.9,103.9);


(lib.Tween37 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.15,0.35,5.9066,6.0685,3.4988,0,0,10.8,6.4);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(4.55,-13.65,5.9062,6.0677,3.5039,0,0,5,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(1.25,-2.9,5.9062,6.0677,3.5039,0,0,5.4,5.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(1.2,-2.9,5.9057,6.0669,3.5056,0,0,5.5,5.4);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_65();
	this.instance_4.setTransform(-29.7,-35.25,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(0.95,-3.5,5.9062,6.0677,3.5039,0,0,5.5,5.4);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66.4,-42.3,132.3,84.1);


(lib.Tween36 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.1,0.3,5.9056,6.0682,-6.4564,0,0,10.8,6.4);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(2.15,-14.35,5.9048,6.0671,-6.4649,0,0,4.9,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(0.75,-3.15,5.9048,6.0671,-6.4649,0,0,5.3,5.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(1.65,-3,5.904,6.0662,-6.4734,0,0,5.5,5.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_64();
	this.instance_4.setTransform(-29.95,-35.35,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(0.7,-3.2,5.9048,6.0671,-6.4649,0,0,5.5,5.5);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.1,-45.5,135.7,90.4);


(lib.Tween35 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.1,0.1,5.9063,6.0681,-39.6102,0,0,10.8,6.4);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(-6,-13.05,5.9057,6.0672,-39.6076,0,0,4.9,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(-0.85,-4,5.9057,6.0672,-39.6076,0,0,5.5,5.3);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(-0.85,-3.55,5.9052,6.0663,-39.6077,0,0,5.5,5.4);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_63();
	this.instance_4.setTransform(-32.45,-34.95,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(-1.35,-3.2,5.9057,6.0672,-39.6076,0,0,5.5,5.5);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.2,-70.5,147.3,140.5);


(lib.Tween34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.25,0.15,5.9063,6.0686,50.8979,0,0,10.8,6.5);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(13.75,-5.6,5.9058,6.0681,50.8954,0,0,5,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(3.85,-0.95,5.9058,6.0681,50.8954,0,0,5.4,5.3);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(4.05,-0.75,5.9053,6.0674,50.8954,0,0,5.5,5.4);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_62();
	this.instance_4.setTransform(-28.5,-32.2,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(4.2,-0.05,5.9058,6.0681,50.8954,0,0,5.7,5.5);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.4,-74.5,140,147.5);


(lib.Tween33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.1,-0.05,5.9058,6.0684,23.6509,0,0,10.8,6.4);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(9.25,-11.9,5.9048,6.0676,23.6509,0,0,5,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(2.4,-2.95,5.9048,6.0676,23.6509,0,0,5.4,5.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(2.4,-2.95,5.9037,6.0667,23.651,0,0,5.5,5.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_61();
	this.instance_4.setTransform(-28.95,-34.3,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(2.15,-3.05,5.9048,6.0676,23.6509,0,0,5.5,5.5);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-73.8,-61.3,147.7,121.3);


(lib.Tween32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.2,0.2,5.9062,6.0681,13.692,0,0,10.8,6.4);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(7.6,-12.95,5.9057,6.0668,13.692,0,0,5,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(2.45,-2.95,5.9057,6.0668,13.692,0,0,5.4,5.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(2.7,-2.9,5.9048,6.0655,13.6937,0,0,5.5,5.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_60();
	this.instance_4.setTransform(-29.25,-34.95,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(2.75,-2.9,5.9057,6.0668,13.692,0,0,5.6,5.5);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.3,-52.7,142.3,104.6);


(lib.Tween31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.05,-0.5,5.9061,6.0684,6.7129,0,0,10.8,6.3);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(5.4,-13.9,5.9052,6.0674,6.7171,0,0,4.9,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(1.6,-4.55,5.9052,6.0674,6.7171,0,0,5.3,5.2);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(0.8,-5.25,5.9045,6.0664,6.7188,0,0,5.2,5.2);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_59();
	this.instance_4.setTransform(-29.55,-35.2,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(1.8,-3.95,5.9052,6.0674,6.7171,0,0,5.5,5.4);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.2,-45.9,136,90.9);


(lib.Tween30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group();
	this.instance.setTransform(-0.15,0.15,5.906,6.0685,0,0,0,10.8,6.4);
	this.instance.alpha = 0.4883;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_0_1();
	this.instance_1.setTransform(3.7,-14.15,5.9052,6.0677,0,0,0,4.9,3.6);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(0.4,-3.85,5.9052,6.0677,0,0,0,5.2,5.3);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(0.1,-4.15,5.9045,6.0669,0,0,0,5.2,5.3);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_58();
	this.instance_4.setTransform(-29.8,-35.25,0.5,0.5);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(1.05,-3.55,5.9052,6.0677,0,0,0,5.5,5.5);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.2,-38.7,127.80000000000001,76.5);


(lib.Tween29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_2();
	this.instance.setTransform(-1.8,0.6,6.2726,6.5172,0,0,0,23.4,23.6);
	this.instance.alpha = 0.7109;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_0();
	this.instance_1.setTransform(-1.5,-0.05,6.2726,6.5172,0,0,0,26.2,26.2);
	this.instance_1.alpha = 0.7109;
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Group_3();
	this.instance_2.setTransform(-48.85,-5.9,6.2726,6.5172,0,0,0,3.3,8.2);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(-20,-0.05,6.2726,6.5172,0,0,0,8.8,12.2);
	this.instance_3.alpha = 0.1914;

	this.instance_4 = new lib.CachedBmp_57();
	this.instance_4.setTransform(-81.15,-86.2,0.5,0.5);

	this.instance_5 = new lib.Group_16();
	this.instance_5.setTransform(-0.55,-0.4,6.2726,6.5172,0,0,0,17.7,17.9);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "screen";

	this.instance_6 = new lib.Path_16();
	this.instance_6.setTransform(-1.55,0.9,6.2716,6.5165,0,0,0,31.7,35.6);
	this.instance_6.alpha = 0.7109;
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_1();
	this.instance_7.setTransform(-1.85,1.2,6.2716,6.5165,0,0,0,35.5,31.8);
	this.instance_7.alpha = 0.7109;
	this.instance_7.compositeOperation = "screen";

	this.instance_8 = new lib.Path_2_1();
	this.instance_8.setTransform(-1.85,1.2,6.2716,6.5165,0,0,0,17.2,35.5);
	this.instance_8.alpha = 0.7109;
	this.instance_8.compositeOperation = "screen";

	this.instance_9 = new lib.Path_3();
	this.instance_9.setTransform(-1.85,1.25,6.2716,6.5165,0,0,0,35.3,17.4);
	this.instance_9.alpha = 0.7109;
	this.instance_9.compositeOperation = "screen";

	this.instance_10 = new lib.Path_4();
	this.instance_10.setTransform(-1.85,0.65,6.2716,6.5165,0,0,0,30.2,10.8);
	this.instance_10.alpha = 0.7109;
	this.instance_10.compositeOperation = "screen";

	this.instance_11 = new lib.Path_5();
	this.instance_11.setTransform(-2.1,1.2,6.2716,6.5165,0,0,0,10.7,30.4);
	this.instance_11.alpha = 0.7109;
	this.instance_11.compositeOperation = "screen";

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(-1.85,1.3,6.2716,6.5165,0,0,0,27.1,7.7);
	this.instance_12.alpha = 0.7109;
	this.instance_12.compositeOperation = "screen";

	this.instance_13 = new lib.Path_7();
	this.instance_13.setTransform(-1.8,0.9,6.2716,6.5165,0,0,0,7.5,27.2);
	this.instance_13.alpha = 0.7109;
	this.instance_13.compositeOperation = "screen";

	this.instance_14 = new lib.Path_8();
	this.instance_14.setTransform(-2.15,0.85,6.2716,6.5165,0,0,0,18.2,31.6);
	this.instance_14.alpha = 0.7109;
	this.instance_14.compositeOperation = "screen";

	this.instance_15 = new lib.Path_9();
	this.instance_15.setTransform(-2.15,0.9,6.2716,6.5165,0,0,0,31.4,18.4);
	this.instance_15.alpha = 0.7109;
	this.instance_15.compositeOperation = "screen";

	this.instance_16 = new lib.Path_10();
	this.instance_16.setTransform(-1.8,0.9,6.2716,6.5165,0,0,0,4.3,36);
	this.instance_16.alpha = 0.7109;
	this.instance_16.compositeOperation = "screen";

	this.instance_17 = new lib.Path_11();
	this.instance_17.setTransform(-1.8,0.85,6.2716,6.5165,0,0,0,4.6,34);
	this.instance_17.alpha = 0.7109;
	this.instance_17.compositeOperation = "screen";

	this.instance_18 = new lib.Path_12();
	this.instance_18.setTransform(-1.9,0.65,6.2716,6.5165,0,0,0,43.6,4.9);
	this.instance_18.alpha = 0.7109;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.Path_13();
	this.instance_19.setTransform(-1.9,0.95,6.2716,6.5165,0,0,0,43.5,5.7);
	this.instance_19.alpha = 0.7109;
	this.instance_19.compositeOperation = "screen";

	this.instance_20 = new lib.Path_14();
	this.instance_20.setTransform(-2.15,0.9,6.2716,6.5165,0,0,0,20.1,25.4);
	this.instance_20.alpha = 0.7109;
	this.instance_20.compositeOperation = "screen";

	this.instance_21 = new lib.Path_15();
	this.instance_21.setTransform(-2.45,0.6,6.2716,6.5165,0,0,0,25.2,20.2);
	this.instance_21.alpha = 0.7109;
	this.instance_21.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-275.3,-233.7,545,465.6);


(lib.Tween28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_2();
	this.instance.setTransform(0.15,0.5,5.8233,5.984,0,0,0,23.5,23.6);
	this.instance.alpha = 0.7109;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_0();
	this.instance_1.setTransform(0.45,0.85,5.8233,5.984,0,0,0,26.3,26.4);
	this.instance_1.alpha = 0.7109;
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Group_3();
	this.instance_2.setTransform(-44.1,-5.45,5.8233,5.984,0,0,0,3.3,8.2);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(-17.3,0.55,5.8233,5.984,0,0,0,8.8,12.3);
	this.instance_3.alpha = 0.1914;

	this.instance_4 = new lib.CachedBmp_56();
	this.instance_4.setTransform(-75.2,-79.15,0.5,0.5);

	this.instance_5 = new lib.Group_16();
	this.instance_5.setTransform(0.7,-0.4,5.8233,5.984,0,0,0,17.7,17.9);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "screen";

	this.instance_6 = new lib.Path_16();
	this.instance_6.setTransform(0.45,0.8,5.8228,5.9833,0,0,0,31.7,35.6);
	this.instance_6.alpha = 0.7109;
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_1();
	this.instance_7.setTransform(0.1,1.1,5.8228,5.9833,0,0,0,35.5,31.9);
	this.instance_7.alpha = 0.7109;
	this.instance_7.compositeOperation = "screen";

	this.instance_8 = new lib.Path_2_1();
	this.instance_8.setTransform(0.15,0.5,5.8228,5.9833,0,0,0,17.2,35.4);
	this.instance_8.alpha = 0.7109;
	this.instance_8.compositeOperation = "screen";

	this.instance_9 = new lib.Path_3();
	this.instance_9.setTransform(0.45,1.1,5.8228,5.9833,0,0,0,35.4,17.4);
	this.instance_9.alpha = 0.7109;
	this.instance_9.compositeOperation = "screen";

	this.instance_10 = new lib.Path_4();
	this.instance_10.setTransform(0.45,0.8,5.8228,5.9833,0,0,0,30.3,10.9);
	this.instance_10.alpha = 0.7109;
	this.instance_10.compositeOperation = "screen";

	this.instance_11 = new lib.Path_5();
	this.instance_11.setTransform(0.45,1.1,5.8228,5.9833,0,0,0,10.8,30.4);
	this.instance_11.alpha = 0.7109;
	this.instance_11.compositeOperation = "screen";

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(0.75,1.1,5.8228,5.9833,0,0,0,27.2,7.7);
	this.instance_12.alpha = 0.7109;
	this.instance_12.compositeOperation = "screen";

	this.instance_13 = new lib.Path_7();
	this.instance_13.setTransform(-0.4,0.8,5.8228,5.9833,0,0,0,7.4,27.2);
	this.instance_13.alpha = 0.7109;
	this.instance_13.compositeOperation = "screen";

	this.instance_14 = new lib.Path_8();
	this.instance_14.setTransform(0.75,0.8,5.8228,5.9833,0,0,0,18.4,31.6);
	this.instance_14.alpha = 0.7109;
	this.instance_14.compositeOperation = "screen";

	this.instance_15 = new lib.Path_9();
	this.instance_15.setTransform(-0.15,0.55,5.8228,5.9833,0,0,0,31.4,18.4);
	this.instance_15.alpha = 0.7109;
	this.instance_15.compositeOperation = "screen";

	this.instance_16 = new lib.Path_10();
	this.instance_16.setTransform(0.75,0.8,5.8228,5.9833,0,0,0,4.4,36);
	this.instance_16.alpha = 0.7109;
	this.instance_16.compositeOperation = "screen";

	this.instance_17 = new lib.Path_11();
	this.instance_17.setTransform(0.75,0.8,5.8228,5.9833,0,0,0,4.7,34);
	this.instance_17.alpha = 0.7109;
	this.instance_17.compositeOperation = "screen";

	this.instance_18 = new lib.Path_12();
	this.instance_18.setTransform(0.1,0.55,5.8228,5.9833,0,0,0,43.6,4.9);
	this.instance_18.alpha = 0.7109;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.Path_13();
	this.instance_19.setTransform(0.65,0.85,5.8228,5.9833,0,0,0,43.6,5.7);
	this.instance_19.alpha = 0.7109;
	this.instance_19.compositeOperation = "screen";

	this.instance_20 = new lib.Path_14();
	this.instance_20.setTransform(-0.15,0.85,5.8228,5.9833,0,0,0,20.1,25.4);
	this.instance_20.alpha = 0.7109;
	this.instance_20.compositeOperation = "screen";

	this.instance_21 = new lib.Path_15();
	this.instance_21.setTransform(-0.45,0.5,5.8228,5.9833,0,0,0,25.2,20.2);
	this.instance_21.alpha = 0.7109;
	this.instance_21.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-253.7,-214.6,506,427.5);


(lib.Tween27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_2();
	this.instance.setTransform(-1.1,0.55,6.0953,6.2624,0,0,0,23.4,23.6);
	this.instance.alpha = 0.7109;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_0();
	this.instance_1.setTransform(-0.8,0.5,6.0953,6.2624,0,0,0,26.2,26.3);
	this.instance_1.alpha = 0.7109;
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Group_3();
	this.instance_2.setTransform(-47.4,-5.7,6.0953,6.2624,0,0,0,3.2,8.2);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(-18.75,0.55,6.0953,6.2624,0,0,0,8.8,12.3);
	this.instance_3.alpha = 0.1914;

	this.instance_4 = new lib.CachedBmp_55();
	this.instance_4.setTransform(-78.8,-83,0.5,0.5);

	this.instance_5 = new lib.Group_16();
	this.instance_5.setTransform(0.15,-0.4,6.0953,6.2624,0,0,0,17.7,17.9);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "screen";

	this.instance_6 = new lib.Path_16();
	this.instance_6.setTransform(-1.15,0.15,6.0946,6.2613,0,0,0,31.6,35.5);
	this.instance_6.alpha = 0.7109;
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_1();
	this.instance_7.setTransform(-0.85,0.75,6.0946,6.2613,0,0,0,35.5,31.8);
	this.instance_7.alpha = 0.7109;
	this.instance_7.compositeOperation = "screen";

	this.instance_8 = new lib.Path_2_1();
	this.instance_8.setTransform(-0.8,-0.2,6.0946,6.2613,0,0,0,17.2,35.3);
	this.instance_8.alpha = 0.7109;
	this.instance_8.compositeOperation = "screen";

	this.instance_9 = new lib.Path_3();
	this.instance_9.setTransform(-0.55,1.15,6.0946,6.2613,0,0,0,35.4,17.4);
	this.instance_9.alpha = 0.7109;
	this.instance_9.compositeOperation = "screen";

	this.instance_10 = new lib.Path_4();
	this.instance_10.setTransform(-1.15,0.5,6.0946,6.2613,0,0,0,30.2,10.8);
	this.instance_10.alpha = 0.7109;
	this.instance_10.compositeOperation = "screen";

	this.instance_11 = new lib.Path_5();
	this.instance_11.setTransform(-1.1,1.1,6.0946,6.2613,0,0,0,10.7,30.4);
	this.instance_11.alpha = 0.7109;
	this.instance_11.compositeOperation = "screen";

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(-0.85,1.15,6.0946,6.2613,0,0,0,27.1,7.7);
	this.instance_12.alpha = 0.7109;
	this.instance_12.compositeOperation = "screen";

	this.instance_13 = new lib.Path_7();
	this.instance_13.setTransform(-1.4,0.8,6.0946,6.2613,0,0,0,7.4,27.2);
	this.instance_13.alpha = 0.7109;
	this.instance_13.compositeOperation = "screen";

	this.instance_14 = new lib.Path_8();
	this.instance_14.setTransform(-0.8,0.15,6.0946,6.2613,0,0,0,18.3,31.5);
	this.instance_14.alpha = 0.7109;
	this.instance_14.compositeOperation = "screen";

	this.instance_15 = new lib.Path_9();
	this.instance_15.setTransform(-1.15,0.8,6.0946,6.2613,0,0,0,31.4,18.4);
	this.instance_15.alpha = 0.7109;
	this.instance_15.compositeOperation = "screen";

	this.instance_16 = new lib.Path_10();
	this.instance_16.setTransform(-0.75,0.15,6.0946,6.2613,0,0,0,4.3,35.9);
	this.instance_16.alpha = 0.7109;
	this.instance_16.compositeOperation = "screen";

	this.instance_17 = new lib.Path_11();
	this.instance_17.setTransform(-0.75,0.8,6.0946,6.2613,0,0,0,4.6,34);
	this.instance_17.alpha = 0.7109;
	this.instance_17.compositeOperation = "screen";

	this.instance_18 = new lib.Path_12();
	this.instance_18.setTransform(-0.9,0.6,6.0946,6.2613,0,0,0,43.6,4.9);
	this.instance_18.alpha = 0.7109;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.Path_13();
	this.instance_19.setTransform(-0.9,0.25,6.0946,6.2613,0,0,0,43.5,5.6);
	this.instance_19.alpha = 0.7109;
	this.instance_19.compositeOperation = "screen";

	this.instance_20 = new lib.Path_14();
	this.instance_20.setTransform(-1.1,0.15,6.0946,6.2613,0,0,0,20.1,25.3);
	this.instance_20.alpha = 0.7109;
	this.instance_20.compositeOperation = "screen";

	this.instance_21 = new lib.Path_15();
	this.instance_21.setTransform(-1.4,0.55,6.0946,6.2613,0,0,0,25.2,20.2);
	this.instance_21.alpha = 0.7109;
	this.instance_21.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-266.6,-224.6,529.6,447.29999999999995);


(lib.Tween26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_2();
	this.instance.setTransform(-0.5,-0.7,5.821,5.9801,0,0,0,23.4,23.4);
	this.instance.alpha = 0.7109;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_0();
	this.instance_1.setTransform(-0.5,0.2,5.821,5.9801,0,0,0,26.2,26.3);
	this.instance_1.alpha = 0.7109;
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Group_3();
	this.instance_2.setTransform(-45,-5.75,5.821,5.9801,0,0,0,3.2,8.2);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(-17.65,0.2,5.821,5.9801,0,0,0,8.8,12.3);
	this.instance_3.alpha = 0.1914;

	this.instance_4 = new lib.CachedBmp_54();
	this.instance_4.setTransform(-75.25,-79.25,0.5,0.5);

	this.instance_5 = new lib.Group_16();
	this.instance_5.setTransform(0.4,-0.7,5.821,5.9801,0,0,0,17.7,17.9);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "screen";

	this.instance_6 = new lib.Path_16();
	this.instance_6.setTransform(-0.8,-0.45,5.8205,5.979,0,0,0,31.5,35.4);
	this.instance_6.alpha = 0.7109;
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_1();
	this.instance_7.setTransform(-1.1,0.45,5.8205,5.979,0,0,0,35.3,31.8);
	this.instance_7.alpha = 0.7109;
	this.instance_7.compositeOperation = "screen";

	this.instance_8 = new lib.Path_2_1();
	this.instance_8.setTransform(-0.75,-0.8,5.8205,5.979,0,0,0,17.1,35.2);
	this.instance_8.alpha = 0.7109;
	this.instance_8.compositeOperation = "screen";

	this.instance_9 = new lib.Path_3();
	this.instance_9.setTransform(-1.1,0.2,5.8205,5.979,0,0,0,35.2,17.3);
	this.instance_9.alpha = 0.7109;
	this.instance_9.compositeOperation = "screen";

	this.instance_10 = new lib.Path_4();
	this.instance_10.setTransform(-0.8,0.2,5.8205,5.979,0,0,0,30.1,10.8);
	this.instance_10.alpha = 0.7109;
	this.instance_10.compositeOperation = "screen";

	this.instance_11 = new lib.Path_5();
	this.instance_11.setTransform(-1.05,0.15,5.8205,5.979,0,0,0,10.6,30.3);
	this.instance_11.alpha = 0.7109;
	this.instance_11.compositeOperation = "screen";

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(-0.8,0.25,5.8205,5.979,0,0,0,27,7.6);
	this.instance_12.alpha = 0.7109;
	this.instance_12.compositeOperation = "screen";

	this.instance_13 = new lib.Path_7();
	this.instance_13.setTransform(-0.8,0.5,5.8205,5.979,0,0,0,7.4,27.2);
	this.instance_13.alpha = 0.7109;
	this.instance_13.compositeOperation = "screen";

	this.instance_14 = new lib.Path_8();
	this.instance_14.setTransform(-0.75,0.45,5.8205,5.979,0,0,0,18.2,31.6);
	this.instance_14.alpha = 0.7109;
	this.instance_14.compositeOperation = "screen";

	this.instance_15 = new lib.Path_9();
	this.instance_15.setTransform(-0.8,0.45,5.8205,5.979,0,0,0,31.3,18.4);
	this.instance_15.alpha = 0.7109;
	this.instance_15.compositeOperation = "screen";

	this.instance_16 = new lib.Path_10();
	this.instance_16.setTransform(-0.75,-0.45,5.8205,5.979,0,0,0,4.2,35.8);
	this.instance_16.alpha = 0.7109;
	this.instance_16.compositeOperation = "screen";

	this.instance_17 = new lib.Path_11();
	this.instance_17.setTransform(-0.75,-0.75,5.8205,5.979,0,0,0,4.5,33.8);
	this.instance_17.alpha = 0.7109;
	this.instance_17.compositeOperation = "screen";

	this.instance_18 = new lib.Path_12();
	this.instance_18.setTransform(-0.55,-0.35,5.8205,5.979,0,0,0,43.5,4.8);
	this.instance_18.alpha = 0.7109;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.Path_13();
	this.instance_19.setTransform(-0.55,-0.35,5.8205,5.979,0,0,0,43.4,5.5);
	this.instance_19.alpha = 0.7109;
	this.instance_19.compositeOperation = "screen";

	this.instance_20 = new lib.Path_14();
	this.instance_20.setTransform(-1.1,-0.75,5.8205,5.979,0,0,0,20,25.2);
	this.instance_20.alpha = 0.7109;
	this.instance_20.compositeOperation = "screen";

	this.instance_21 = new lib.Path_15();
	this.instance_21.setTransform(-0.75,0.2,5.8205,5.979,0,0,0,25.2,20.2);
	this.instance_21.alpha = 0.7109;
	this.instance_21.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-253.7,-214.5,505.79999999999995,427.2);


(lib.Tween25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_2();
	this.instance.setTransform(-1.15,0.3,6.2339,6.4062,0,0,0,23.4,23.6);
	this.instance.alpha = 0.7109;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_0();
	this.instance_1.setTransform(-0.8,0.3,6.2339,6.4062,0,0,0,26.2,26.3);
	this.instance_1.alpha = 0.7109;
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Group_3();
	this.instance_2.setTransform(-48.5,-6.4,6.2339,6.4062,0,0,0,3.2,8.2);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(-19.2,-0.35,6.2339,6.4062,0,0,0,8.8,12.2);
	this.instance_3.alpha = 0.1914;

	this.instance_4 = new lib.CachedBmp_53();
	this.instance_4.setTransform(-80.6,-84.65,0.5,0.5);

	this.instance_5 = new lib.Group_16();
	this.instance_5.setTransform(0.15,-1,6.2339,6.4062,0,0,0,17.7,17.9);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "screen";

	this.instance_6 = new lib.Path_16();
	this.instance_6.setTransform(-0.55,0.25,6.233,6.4058,0,0,0,31.7,35.6);
	this.instance_6.alpha = 0.7109;
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_1();
	this.instance_7.setTransform(-0.9,0.25,6.233,6.4058,0,0,0,35.5,31.8);
	this.instance_7.alpha = 0.7109;
	this.instance_7.compositeOperation = "screen";

	this.instance_8 = new lib.Path_2_1();
	this.instance_8.setTransform(-1.45,-0.05,6.233,6.4058,0,0,0,17.1,35.3);
	this.instance_8.alpha = 0.7109;
	this.instance_8.compositeOperation = "screen";

	this.instance_9 = new lib.Path_3();
	this.instance_9.setTransform(-0.55,0.25,6.233,6.4058,0,0,0,35.4,17.3);
	this.instance_9.alpha = 0.7109;
	this.instance_9.compositeOperation = "screen";

	this.instance_10 = new lib.Path_4();
	this.instance_10.setTransform(-1.15,0.25,6.233,6.4058,0,0,0,30.2,10.9);
	this.instance_10.alpha = 0.7109;
	this.instance_10.compositeOperation = "screen";

	this.instance_11 = new lib.Path_5();
	this.instance_11.setTransform(-1.1,0.3,6.233,6.4058,0,0,0,10.7,30.3);
	this.instance_11.alpha = 0.7109;
	this.instance_11.compositeOperation = "screen";

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(-0.85,0.25,6.233,6.4058,0,0,0,27.1,7.7);
	this.instance_12.alpha = 0.7109;
	this.instance_12.compositeOperation = "screen";

	this.instance_13 = new lib.Path_7();
	this.instance_13.setTransform(-1.45,-0.05,6.233,6.4058,0,0,0,7.4,27.2);
	this.instance_13.alpha = 0.7109;
	this.instance_13.compositeOperation = "screen";

	this.instance_14 = new lib.Path_8();
	this.instance_14.setTransform(-1.45,0.55,6.233,6.4058,0,0,0,18.2,31.6);
	this.instance_14.alpha = 0.7109;
	this.instance_14.compositeOperation = "screen";

	this.instance_15 = new lib.Path_9();
	this.instance_15.setTransform(-1.2,0.25,6.233,6.4058,0,0,0,31.4,18.4);
	this.instance_15.alpha = 0.7109;
	this.instance_15.compositeOperation = "screen";

	this.instance_16 = new lib.Path_10();
	this.instance_16.setTransform(-1.4,-0.05,6.233,6.4058,0,0,0,4.2,35.9);
	this.instance_16.alpha = 0.7109;
	this.instance_16.compositeOperation = "screen";

	this.instance_17 = new lib.Path_11();
	this.instance_17.setTransform(-1.4,0.25,6.233,6.4058,0,0,0,4.5,34);
	this.instance_17.alpha = 0.7109;
	this.instance_17.compositeOperation = "screen";

	this.instance_18 = new lib.Path_12();
	this.instance_18.setTransform(-0.9,0.3,6.233,6.4058,0,0,0,43.6,5);
	this.instance_18.alpha = 0.7109;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.Path_13();
	this.instance_19.setTransform(-0.85,-0.05,6.233,6.4058,0,0,0,43.5,5.7);
	this.instance_19.alpha = 0.7109;
	this.instance_19.compositeOperation = "screen";

	this.instance_20 = new lib.Path_14();
	this.instance_20.setTransform(-1.15,0.25,6.233,6.4058,0,0,0,20.1,25.4);
	this.instance_20.alpha = 0.7109;
	this.instance_20.compositeOperation = "screen";

	this.instance_21 = new lib.Path_15();
	this.instance_21.setTransform(-1.5,-0.05,6.233,6.4058,0,0,0,25.2,20.2);
	this.instance_21.alpha = 0.7109;
	this.instance_21.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-272.6,-230,541.6,457.7);


(lib.Tween24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_0_2();
	this.instance.setTransform(-0.25,0.3,5.9052,6.0677,0,0,0,23.4,23.6);
	this.instance.alpha = 0.7109;
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_0();
	this.instance_1.setTransform(-0.3,-0.05,5.9052,6.0677,0,0,0,26.2,26.2);
	this.instance_1.alpha = 0.7109;
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Group_3();
	this.instance_2.setTransform(-44.8,-5.75,5.9052,6.0677,0,0,0,3.4,8.2);
	this.instance_2.alpha = 0.3008;

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(-18,0,5.9052,6.0677,0,0,0,8.8,12.2);
	this.instance_3.alpha = 0.1914;

	this.instance_4 = new lib.CachedBmp_52();
	this.instance_4.setTransform(-76.45,-80.25,0.5,0.5);

	this.instance_5 = new lib.Group_16();
	this.instance_5.setTransform(0.35,-0.35,5.9052,6.0677,0,0,0,17.6,17.9);
	this.instance_5.alpha = 0.5;
	this.instance_5.compositeOperation = "screen";

	this.instance_6 = new lib.Path_16();
	this.instance_6.setTransform(0,-0.1,5.9045,6.0669,0,0,0,31.6,35.4);
	this.instance_6.alpha = 0.7109;
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_1();
	this.instance_7.setTransform(-0.35,0.2,5.9045,6.0669,0,0,0,35.4,31.7);
	this.instance_7.alpha = 0.7109;
	this.instance_7.compositeOperation = "screen";

	this.instance_8 = new lib.Path_2_1();
	this.instance_8.setTransform(-0.6,-0.4,5.9045,6.0669,0,0,0,17.1,35.2);
	this.instance_8.alpha = 0.7109;
	this.instance_8.compositeOperation = "screen";

	this.instance_9 = new lib.Path_3();
	this.instance_9.setTransform(-0.3,0,5.9045,6.0669,0,0,0,35.2,17.2);
	this.instance_9.alpha = 0.7109;
	this.instance_9.compositeOperation = "screen";

	this.instance_10 = new lib.Path_4();
	this.instance_10.setTransform(-0.65,0.25,5.9045,6.0669,0,0,0,30.2,10.8);
	this.instance_10.alpha = 0.7109;
	this.instance_10.compositeOperation = "screen";

	this.instance_11 = new lib.Path_5();
	this.instance_11.setTransform(-0.55,-0.1,5.9045,6.0669,0,0,0,10.6,30.2);
	this.instance_11.alpha = 0.7109;
	this.instance_11.compositeOperation = "screen";

	this.instance_12 = new lib.Path_6();
	this.instance_12.setTransform(-0.3,-0.3,5.9045,6.0669,0,0,0,27.1,7.5);
	this.instance_12.alpha = 0.7109;
	this.instance_12.compositeOperation = "screen";

	this.instance_13 = new lib.Path_7();
	this.instance_13.setTransform(-0.25,-0.05,5.9045,6.0669,0,0,0,7.4,27.1);
	this.instance_13.alpha = 0.7109;
	this.instance_13.compositeOperation = "screen";

	this.instance_14 = new lib.Path_8();
	this.instance_14.setTransform(-0.3,-0.05,5.9045,6.0669,0,0,0,18.3,31.5);
	this.instance_14.alpha = 0.7109;
	this.instance_14.compositeOperation = "screen";

	this.instance_15 = new lib.Path_9();
	this.instance_15.setTransform(-0.3,-0.05,5.9045,6.0669,0,0,0,31.4,18.3);
	this.instance_15.alpha = 0.7109;
	this.instance_15.compositeOperation = "screen";

	this.instance_16 = new lib.Path_10();
	this.instance_16.setTransform(-0.25,0.25,5.9045,6.0669,0,0,0,4.4,35.9);
	this.instance_16.alpha = 0.7109;
	this.instance_16.compositeOperation = "screen";

	this.instance_17 = new lib.Path_11();
	this.instance_17.setTransform(-0.25,0.2,5.9045,6.0669,0,0,0,4.6,33.9);
	this.instance_17.alpha = 0.7109;
	this.instance_17.compositeOperation = "screen";

	this.instance_18 = new lib.Path_12();
	this.instance_18.setTransform(-0.35,0.35,5.9045,6.0669,0,0,0,43.5,4.9);
	this.instance_18.alpha = 0.7109;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.Path_13();
	this.instance_19.setTransform(-0.35,0,5.9045,6.0669,0,0,0,43.4,5.6);
	this.instance_19.alpha = 0.7109;
	this.instance_19.compositeOperation = "screen";

	this.instance_20 = new lib.Path_14();
	this.instance_20.setTransform(-0.55,-0.35,5.9045,6.0669,0,0,0,20.1,25.2);
	this.instance_20.alpha = 0.7109;
	this.instance_20.compositeOperation = "screen";

	this.instance_21 = new lib.Path_15();
	this.instance_21.setTransform(-0.3,-0.05,5.9045,6.0669,0,0,0,25.2,20.1);
	this.instance_21.alpha = 0.7109;
	this.instance_21.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-257.2,-217.5,513.1,433.5);


(lib.Tween23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_4();
	this.instance.setTransform(-0.1,2.35,5.906,6.0685,0,0,0,14.5,6.8);
	this.instance.alpha = 0.2383;

	this.instance_1 = new lib.Path_17();
	this.instance_1.setTransform(-0.15,-0.35,5.9052,6.0677,0,0,0,6.3,6.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1_2();
	this.instance_2.setTransform(12.3,0.6,5.9052,6.0677,0,0,0,4.2,6.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2_2();
	this.instance_3.setTransform(-1.3,-0.35,5.9052,6.0677,0,0,0,6.5,6.7);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_51();
	this.instance_4.setTransform(-38.6,-40.35,0.5,0.5);

	this.instance_5 = new lib.Group_1_1();
	this.instance_5.setTransform(-0.4,-1.3,5.9052,6.0677,0,0,0,7,6.9);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.7,-43.1,170.10000000000002,85.5);


(lib.Tween22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_4();
	this.instance.setTransform(-0.4,0.25,5.9059,6.0682,39.3159,0,0,14.5,6.8);
	this.instance.alpha = 0.2383;

	this.instance_1 = new lib.Path_17();
	this.instance_1.setTransform(2.25,-3.4,5.9047,6.0674,39.3193,0,0,6.2,6.2);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1_2();
	this.instance_2.setTransform(11.7,7.9,5.9047,6.0674,39.3193,0,0,4.5,6.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2_2();
	this.instance_3.setTransform(2.35,-2.6,5.9047,6.0674,39.3193,0,0,6.7,6.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_50();
	this.instance_4.setTransform(-37.1,-41.5,0.5,0.5);

	this.instance_5 = new lib.Group_1_1();
	this.instance_5.setTransform(1.1,-2.45,5.9047,6.0674,39.3193,0,0,6.9,7);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-85.9,183.1,170.7);


(lib.Tween21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_4();
	this.instance.setTransform(-0.1,-0.5,5.9065,6.0686,-34.9234,0,0,14.5,6.7);
	this.instance.alpha = 0.2383;

	this.instance_1 = new lib.Path_17();
	this.instance_1.setTransform(-1.35,-3.25,5.906,6.068,-34.9261,0,0,6.4,6.4);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1_2();
	this.instance_2.setTransform(10.55,-9,5.906,6.068,-34.9261,0,0,4.4,6.5);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2_2();
	this.instance_3.setTransform(-2.6,-2,5.906,6.068,-34.9261,0,0,6.5,6.6);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_49();
	this.instance_4.setTransform(-40.4,-41.6,0.5,0.5);

	this.instance_5 = new lib.Group_1_1();
	this.instance_5.setTransform(-1.9,-2.45,5.906,6.068,-34.9261,0,0,7,7);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.6,-82.2,186.1,164.10000000000002);


(lib.Tween20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_4();
	this.instance.setTransform(0.4,-0.3,5.9067,6.0689,-18.4435,0,0,14.6,6.7);
	this.instance.alpha = 0.2383;

	this.instance_1 = new lib.Path_17();
	this.instance_1.setTransform(-0.85,-4,5.9061,6.068,-18.4487,0,0,6.4,6.2);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1_2();
	this.instance_2.setTransform(12.4,-5.5,5.9061,6.068,-18.4487,0,0,4.4,6.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2_2();
	this.instance_3.setTransform(-0.8,-2.1,5.9061,6.068,-18.4487,0,0,6.7,6.7);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_48();
	this.instance_4.setTransform(-39.5,-42.2,0.5,0.5);

	this.instance_5 = new lib.Group_1_1();
	this.instance_5.setTransform(-1.4,-2.9,5.9061,6.068,-18.4487,0,0,7,6.9);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94.2,-65.3,187.10000000000002,130.89999999999998);


(lib.Tween19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_4();
	this.instance.setTransform(-0.1,2.35,5.906,6.0685,0,0,0,14.5,6.8);
	this.instance.alpha = 0.2383;

	this.instance_1 = new lib.Path_17();
	this.instance_1.setTransform(-0.15,-0.35,5.9052,6.0677,0,0,0,6.3,6.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1_2();
	this.instance_2.setTransform(12.3,1.2,5.9052,6.0677,0,0,0,4.2,6.5);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2_2();
	this.instance_3.setTransform(-1.3,-0.35,5.9052,6.0677,0,0,0,6.5,6.7);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_47();
	this.instance_4.setTransform(-38.6,-40.35,0.5,0.5);

	this.instance_5 = new lib.Group_1_1();
	this.instance_5.setTransform(-0.7,-0.7,5.9052,6.0677,0,0,0,6.9,7);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.7,-43.1,170.10000000000002,85.5);


(lib.Tween18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group_4();
	this.instance.setTransform(-0.4,2.05,5.906,6.0685,0,0,0,14.4,6.8);
	this.instance.alpha = 0.2383;

	this.instance_1 = new lib.Path_17();
	this.instance_1.setTransform(0.75,-0.95,5.9052,6.0677,0,0,0,6.4,6.4);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_1_2();
	this.instance_2.setTransform(13.15,0.6,5.9052,6.0677,0,0,0,4.3,6.4);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_2_2();
	this.instance_3.setTransform(0.15,-0.95,5.9052,6.0677,0,0,0,6.7,6.6);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_46();
	this.instance_4.setTransform(-38.6,-40.35,0.5,0.5);

	this.instance_5 = new lib.Group_1_1();
	this.instance_5.setTransform(-0.1,-1.3,5.9052,6.0677,0,0,0,7,6.9);
	this.instance_5.alpha = 0.6797;
	this.instance_5.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.4,-43.1,170.10000000000002,85.2);


(lib.Tween17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CompoundPath();
	this.instance.setTransform(-0.3,-1.1,5.9059,6.0671,-21.5222,0,0,9.5,2.6);
	this.instance.alpha = 0.0781;

	this.instance_1 = new lib.CompoundPath_1();
	this.instance_1.setTransform(-0.4,0.3,5.9059,6.0671,-21.5222,0,0,9.9,3);
	this.instance_1.alpha = 0.5781;

	this.instance_2 = new lib.CompoundPath_2();
	this.instance_2.setTransform(0.3,-0.35,5.9059,6.0671,-21.5222,0,0,12.2,3.5);
	this.instance_2.alpha = 0.25;

	this.instance_3 = new lib.CompoundPath_3();
	this.instance_3.setTransform(-0.35,-1.1,5.9059,6.0671,-21.5222,0,0,13.1,3.6);
	this.instance_3.alpha = 0.6719;

	this.instance_4 = new lib.CompoundPath_4();
	this.instance_4.setTransform(-0.3,-0.15,5.9059,6.0671,-21.5222,0,0,15.2,4.3);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.CompoundPath_5();
	this.instance_5.setTransform(-0.55,-0.05,5.9059,6.0671,-21.5222,0,0,15.8,4.6);
	this.instance_5.alpha = 0.3984;

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-0.55,0.05,5.9052,6.0659,-21.5221,0,0,5.5,5.5);
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_3();
	this.instance_7.setTransform(5.85,-0.6,5.9052,6.0659,-21.5221,0,0,4.7,5.4);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_45();
	this.instance_8.setTransform(-32.4,-32.8,0.5,0.5);

	this.instance_9 = new lib.Path_3_2();
	this.instance_9.setTransform(-0.85,0.15,5.9052,6.0659,-21.5221,0,0,5.7,5.8);
	this.instance_9.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.3,-60.1,193.1,119.1);


(lib.Tween16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CompoundPath();
	this.instance.setTransform(-0.55,0.6,5.9048,6.0668,-39.0573,0,0,9.5,2.8);
	this.instance.alpha = 0.0781;

	this.instance_1 = new lib.CompoundPath_1();
	this.instance_1.setTransform(-0.8,0.8,5.9048,6.0668,-39.0573,0,0,9.9,3);
	this.instance_1.alpha = 0.5781;

	this.instance_2 = new lib.CompoundPath_2();
	this.instance_2.setTransform(-0.9,0.6,5.9048,6.0668,-39.0573,0,0,12.1,3.5);
	this.instance_2.alpha = 0.25;

	this.instance_3 = new lib.CompoundPath_3();
	this.instance_3.setTransform(-0.4,0.8,5.9048,6.0668,-39.0573,0,0,13.1,3.9);
	this.instance_3.alpha = 0.6719;

	this.instance_4 = new lib.CompoundPath_4();
	this.instance_4.setTransform(-0.8,0.8,5.9048,6.0668,-39.0573,0,0,15.2,4.4);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.CompoundPath_5();
	this.instance_5.setTransform(-0.85,1.2,5.9048,6.0668,-39.0573,0,0,15.8,4.7);
	this.instance_5.alpha = 0.3984;

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-1.25,1.25,5.9036,6.0658,-39.059,0,0,5.5,5.6);
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_3();
	this.instance_7.setTransform(3.9,-1.35,5.9036,6.0658,-39.059,0,0,4.6,5.4);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_44();
	this.instance_8.setTransform(-32.55,-32.35,0.5,0.5);

	this.instance_9 = new lib.Path_3_2();
	this.instance_9.setTransform(-1.2,1.2,5.9036,6.0658,-39.059,0,0,5.7,5.9);
	this.instance_9.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91,-79.5,178.9,159.6);


(lib.Tween15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CompoundPath();
	this.instance.setTransform(0.3,-0.45,5.9048,6.0671,57.1893,0,0,9.5,2.8);
	this.instance.alpha = 0.0781;

	this.instance_1 = new lib.CompoundPath_1();
	this.instance_1.setTransform(0.5,-0.2,5.9048,6.0671,57.1893,0,0,10,3);
	this.instance_1.alpha = 0.5781;

	this.instance_2 = new lib.CompoundPath_2();
	this.instance_2.setTransform(-0.1,-0.5,5.9048,6.0671,57.1893,0,0,12.1,3.6);
	this.instance_2.alpha = 0.25;

	this.instance_3 = new lib.CompoundPath_3();
	this.instance_3.setTransform(0.55,-0.6,5.9048,6.0671,57.1893,0,0,13.1,3.8);
	this.instance_3.alpha = 0.6719;

	this.instance_4 = new lib.CompoundPath_4();
	this.instance_4.setTransform(1.2,-1.35,5.9048,6.0671,57.1893,0,0,15.2,4.2);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.CompoundPath_5();
	this.instance_5.setTransform(0.55,-0.65,5.9048,6.0671,57.1893,0,0,15.9,4.6);
	this.instance_5.alpha = 0.3984;

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(0.9,-1.15,5.904,6.0659,57.1859,0,0,5.5,5.5);
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_3();
	this.instance_7.setTransform(2.05,4.05,5.904,6.0659,57.1859,0,0,4.5,5.4);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_43();
	this.instance_8.setTransform(-32.8,-32.55,0.5,0.5);

	this.instance_9 = new lib.Path_3_2();
	this.instance_9.setTransform(0.2,-1.1,5.904,6.0659,57.1859,0,0,5.7,5.9);
	this.instance_9.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-94.4,146.7,185.9);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CompoundPath();
	this.instance.setTransform(0.1,0.15,5.9065,6.0674,7.7339,0,0,9.5,2.9);
	this.instance.alpha = 0.0781;

	this.instance_1 = new lib.CompoundPath_1();
	this.instance_1.setTransform(0.05,0.15,5.9065,6.0674,7.7339,0,0,10,3.1);
	this.instance_1.alpha = 0.5781;

	this.instance_2 = new lib.CompoundPath_2();
	this.instance_2.setTransform(0.4,-0.1,5.9065,6.0674,7.7339,0,0,12.2,3.6);
	this.instance_2.alpha = 0.25;

	this.instance_3 = new lib.CompoundPath_3();
	this.instance_3.setTransform(0.05,-0.15,5.9065,6.0674,7.7339,0,0,13.1,3.9);
	this.instance_3.alpha = 0.6719;

	this.instance_4 = new lib.CompoundPath_4();
	this.instance_4.setTransform(-0.15,-0.45,5.9065,6.0674,7.7339,0,0,15.2,4.4);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.CompoundPath_5();
	this.instance_5.setTransform(0.1,-0.15,5.9065,6.0674,7.7339,0,0,15.9,4.7);
	this.instance_5.alpha = 0.3984;

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-0.35,-0.8,5.9061,6.0664,7.7391,0,0,5.5,5.6);
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_3();
	this.instance_7.setTransform(5.6,1.2,5.9061,6.0664,7.7391,0,0,4.7,5.4);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_42();
	this.instance_8.setTransform(-32.35,-32.65,0.5,0.5);

	this.instance_9 = new lib.Path_3_2();
	this.instance_9.setTransform(0.4,-0.1,5.9061,6.0664,7.7391,0,0,5.9,6);
	this.instance_9.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96.1,-41,191.7,79.2);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CompoundPath();
	this.instance.setTransform(0.1,-0.1,5.9052,6.0677,0,0,0,9.5,2.8);
	this.instance.alpha = 0.0781;

	this.instance_1 = new lib.CompoundPath_1();
	this.instance_1.setTransform(0.1,-0.1,5.9052,6.0677,0,0,0,10,3);
	this.instance_1.alpha = 0.5781;

	this.instance_2 = new lib.CompoundPath_2();
	this.instance_2.setTransform(-0.2,0.2,5.9052,6.0677,0,0,0,12.1,3.6);
	this.instance_2.alpha = 0.25;

	this.instance_3 = new lib.CompoundPath_3();
	this.instance_3.setTransform(0.05,0.2,5.9052,6.0677,0,0,0,13.1,3.9);
	this.instance_3.alpha = 0.6719;

	this.instance_4 = new lib.CompoundPath_4();
	this.instance_4.setTransform(-0.25,0.2,5.9052,6.0677,0,0,0,15.2,4.4);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.CompoundPath_5();
	this.instance_5.setTransform(0.1,0.2,5.9052,6.0677,0,0,0,15.9,4.7);
	this.instance_5.alpha = 0.3984;

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-0.55,-0.1,5.9045,6.0669,0,0,0,5.5,5.7);
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_3();
	this.instance_7.setTransform(5.7,0.2,5.9045,6.0669,0,0,0,4.7,5.2);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_41();
	this.instance_8.setTransform(-32.25,-33,0.5,0.5);

	this.instance_9 = new lib.Path_3_2();
	this.instance_9.setTransform(0.4,0.2,5.9045,6.0669,0,0,0,5.9,5.9);
	this.instance_9.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.5,-35.6,186,69.5);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CompoundPath();
	this.instance.setTransform(-0.2,-0.1,5.9052,6.0677,0,0,0,9.5,2.8);
	this.instance.alpha = 0.0781;

	this.instance_1 = new lib.CompoundPath_1();
	this.instance_1.setTransform(-0.2,-0.1,5.9052,6.0677,0,0,0,10,3);
	this.instance_1.alpha = 0.5781;

	this.instance_2 = new lib.CompoundPath_2();
	this.instance_2.setTransform(-0.2,-0.1,5.9052,6.0677,0,0,0,12.2,3.5);
	this.instance_2.alpha = 0.25;

	this.instance_3 = new lib.CompoundPath_3();
	this.instance_3.setTransform(-0.55,0.2,5.9052,6.0677,0,0,0,13.1,3.9);
	this.instance_3.alpha = 0.6719;

	this.instance_4 = new lib.CompoundPath_4();
	this.instance_4.setTransform(-0.85,0.2,5.9052,6.0677,0,0,0,15.2,4.4);
	this.instance_4.alpha = 0.25;

	this.instance_5 = new lib.CompoundPath_5();
	this.instance_5.setTransform(-0.5,0.2,5.9052,6.0677,0,0,0,15.9,4.7);
	this.instance_5.alpha = 0.3984;

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-1.4,-0.45,5.9045,6.0669,0,0,0,5.5,5.5);
	this.instance_6.compositeOperation = "screen";

	this.instance_7 = new lib.Path_1_3();
	this.instance_7.setTransform(4.5,0.2,5.9045,6.0669,0,0,0,4.5,5.2);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_40();
	this.instance_8.setTransform(-32.25,-33,0.5,0.5);

	this.instance_9 = new lib.Path_3_2();
	this.instance_9.setTransform(-0.8,0.2,5.9045,6.0669,0,0,0,5.7,5.9);
	this.instance_9.compositeOperation = "screen";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94.1,-35.6,186,69.5);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_20();
	this.instance.setTransform(-1,-1.45,5.9052,6.0677,0,0,0,7.5,7.5);
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_4();
	this.instance_1.setTransform(4.85,-0.85,5.9052,6.0677,0,0,0,6.6,7.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_39();
	this.instance_2.setTransform(-46.75,-47.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.7,-47.9,93,95.5);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_20();
	this.instance.setTransform(-1,-0.55,5.9052,6.0677,0,0,0,7.5,7.5);
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_4();
	this.instance_1.setTransform(5.15,0.05,5.9052,6.0677,0,0,0,6.7,7.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_38();
	this.instance_2.setTransform(-46.75,-47.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.7,-47.9,93,95.5);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_20();
	this.instance.setTransform(-1,-0.85,5.9052,6.0677,0,0,0,7.5,7.5);
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_4();
	this.instance_1.setTransform(4.85,-0.25,5.9052,6.0677,0,0,0,6.6,7.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_37();
	this.instance_2.setTransform(-46.75,-47.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.7,-47.9,93,95.5);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_20();
	this.instance.setTransform(-1,-0.55,5.9052,6.0677,0,0,0,7.5,7.6);
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_4();
	this.instance_1.setTransform(4.85,-0.55,5.9052,6.0677,0,0,0,6.6,7.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_36();
	this.instance_2.setTransform(-46.75,-47.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.7,-47.9,93,95.5);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Path_20();
	this.instance.setTransform(-1,-0.85,5.9052,6.0677,0,0,0,7.5,7.5);
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.Path_1_4();
	this.instance_1.setTransform(4.85,-0.25,5.9052,6.0677,0,0,0,6.6,7.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_35();
	this.instance_2.setTransform(-46.75,-47.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.7,-47.9,93,95.5);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(3.7,-5.3,5.9052,6.0677,0,0,0,22.8,15.3);

	this.instance_1 = new lib.Path_0_3();
	this.instance_1.setTransform(-2.15,-0.75,5.9052,6.0677,0,0,0,11.8,11.8);
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(29.1,23.2,5.9052,6.0677,0,0,0,1.2,1.2);
	this.instance_2.compositeOperation = "screen";

	this.instance_3 = new lib.Path_2_3();
	this.instance_3.setTransform(-5.15,-10.75,5.9052,6.0677,0,0,0,3.5,3.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_34();
	this.instance_4.setTransform(-41.65,-70.7,0.5,0.5);

	this.instance_5 = new lib.Path_21();
	this.instance_5.setTransform(-2.8,-1.65,5.9045,6.0669,0,0,0,11.8,11.8);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_33();
	this.instance_6.setTransform(-71.3,-70.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-131.2,-98.4,268.7,185.60000000000002);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(5,-3.5,5.9048,6.0674,10.2287,0,0,22.9,15.5);

	this.instance_1 = new lib.Path_0_3();
	this.instance_1.setTransform(-0.85,-0.6,5.9048,6.0674,10.2287,0,0,12,11.9);
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(24.9,27.45,5.9048,6.0674,10.2287,0,0,1.2,1.1);
	this.instance_2.compositeOperation = "screen";

	this.instance_3 = new lib.Path_2_3();
	this.instance_3.setTransform(-2.5,-11.65,5.9048,6.0674,10.2287,0,0,3.6,3.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_32();
	this.instance_4.setTransform(-50.6,-69.95,0.5,0.5);

	this.instance_5 = new lib.Path_21();
	this.instance_5.setTransform(-0.95,-1.85,5.904,6.0666,10.2287,0,0,12.1,11.8);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_31();
	this.instance_6.setTransform(-70.65,-71.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144.5,-120.4,297.3,230.4);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(6.45,-4.9,5.9045,6.0675,23.1968,0,0,22.8,15.3);

	this.instance_1 = new lib.Path_0_3();
	this.instance_1.setTransform(-0.15,-1.5,5.9045,6.0675,23.1968,0,0,12,12);
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(18.8,31.45,5.9045,6.0675,23.1968,0,0,1.2,1.2);
	this.instance_2.compositeOperation = "screen";

	this.instance_3 = new lib.Path_2_3();
	this.instance_3.setTransform(1.05,-13.2,5.9045,6.0675,23.1968,0,0,3.6,3.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_30();
	this.instance_4.setTransform(-60.1,-66.8,0.5,0.5);

	this.instance_5 = new lib.Path_21();
	this.instance_5.setTransform(0,-2.7,5.9037,6.0661,23.1978,0,0,12,11.9);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_29();
	this.instance_6.setTransform(-70.25,-73.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154,-143.6,320,276.4);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(7.45,-0.25,5.9051,6.0667,58.6571,0,0,22.9,15.4);

	this.instance_1 = new lib.Path_0_3();
	this.instance_1.setTransform(1,-2.6,5.9051,6.0667,58.6571,0,0,11.9,11.8);
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(-2.9,35.75,5.9051,6.0667,58.6571,0,0,1.2,1.1);
	this.instance_2.compositeOperation = "screen";

	this.instance_3 = new lib.Path_2_3();
	this.instance_3.setTransform(7.6,-10.4,5.9051,6.0667,58.6571,0,0,3.6,3.6);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_28();
	this.instance_4.setTransform(-69.3,-37.7,0.5,0.5);

	this.instance_5 = new lib.Path_21();
	this.instance_5.setTransform(1.25,-3.4,5.9041,6.0657,58.6521,0,0,11.9,11.8);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_27();
	this.instance_6.setTransform(-69.4,-72.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-141.5,-164.7,298.3,326);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(3.15,-5.1,5.9056,6.0676,-8.5177,0,0,22.8,15.3);

	this.instance_1 = new lib.Path_0_3();
	this.instance_1.setTransform(-1.45,-0.1,5.9056,6.0676,-8.5177,0,0,11.9,11.8);
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(32.15,19.1,5.9056,6.0676,-8.5177,0,0,1.1,1.2);
	this.instance_2.compositeOperation = "screen";

	this.instance_3 = new lib.Path_2_3();
	this.instance_3.setTransform(-6.3,-8.85,5.9056,6.0676,-8.5177,0,0,3.5,3.6);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_26();
	this.instance_4.setTransform(-32.55,-70.9,0.5,0.5);

	this.instance_5 = new lib.Path_21();
	this.instance_5.setTransform(-1.4,-0.05,5.9049,6.0663,-8.5254,0,0,12,11.8);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_25();
	this.instance_6.setTransform(-71.1,-70.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144.1,-116.9,293.29999999999995,223.3);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(3.7,-4.4,5.9052,6.0677,0,0,0,22.8,15.3);

	this.instance_1 = new lib.Path_0_3();
	this.instance_1.setTransform(-2.15,-0.45,5.9052,6.0677,0,0,0,11.8,11.7);
	this.instance_1.compositeOperation = "screen";

	this.instance_2 = new lib.Path_1_5();
	this.instance_2.setTransform(29.1,23.8,5.9052,6.0677,0,0,0,1.2,1.2);
	this.instance_2.compositeOperation = "screen";

	this.instance_3 = new lib.Path_2_3();
	this.instance_3.setTransform(-5.15,-10.15,5.9052,6.0677,0,0,0,3.5,3.5);
	this.instance_3.compositeOperation = "screen";

	this.instance_4 = new lib.CachedBmp_34();
	this.instance_4.setTransform(-41.65,-70.7,0.5,0.5);

	this.instance_5 = new lib.Path_21();
	this.instance_5.setTransform(-2.8,-0.75,5.9045,6.0669,0,0,0,11.8,11.7);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_23();
	this.instance_6.setTransform(-71.3,-70.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-131.2,-97.5,268.7,185.6);


(lib.location = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween82("synched",0);

	this.instance_1 = new lib.Tween83("synched",0);
	this.instance_1.setTransform(-0.05,-30.05);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween84("synched",0);
	this.instance_2.setTransform(-0.05,1.95);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween85("synched",0);
	this.instance_3.setTransform(-0.05,-8.05);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween86("synched",0);
	this.instance_4.setTransform(-0.05,-0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,x:-0.05,y:-30.05},2).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},2).to({_off:true,y:1.95},2).wait(5));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},2).to({_off:true,y:-8.05},2).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},2).to({_off:true,y:-0.05},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52,-82,104,135.9);


// stage content:
(lib.Untitled1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_17
	this.location = new lib.location();
	this.location.name = "location";
	this.location.setTransform(375.95,443.95);
	new cjs.ButtonHelper(this.location, 0, 1, 2, false, new lib.location(), 3);

	this.timeline.addTween(cjs.Tween.get(this.location).wait(300));

	// 圖層_52
	this.instance = new lib.Path_0();
	this.instance.setTransform(235.7,502.9,5.9045,6.0669,0,0,0,2.5,2.5);
	this.instance.compositeOperation = "screen";

	this.instance_1 = new lib.CachedBmp_4();
	this.instance_1.setTransform(221.8,490.6,0.5,0.5);

	this.instance_2 = new lib.Path();
	this.instance_2.setTransform(235.7,502.9,5.9036,6.0656,0,0,0,2.6,2.6);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.CachedBmp_1();
	this.instance_3.setTransform(221.65,488.2,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_3();
	this.instance_4.setTransform(221.65,488.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_4},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},299).wait(1));

	// 圖層_51
	this.instance_5 = new lib.Tween30("synched",0);
	this.instance_5.setTransform(170.05,536.2);

	this.instance_6 = new lib.Tween31("synched",0);
	this.instance_6.setTransform(277.75,461.75);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween32("synched",0);
	this.instance_7.setTransform(363.6,425.4);
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween33("synched",0);
	this.instance_8.setTransform(499.6,402.8);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween34("synched",0);
	this.instance_9.setTransform(587.6,416.4);
	this.instance_9._off = true;

	this.instance_10 = new lib.Tween35("synched",0);
	this.instance_10.setTransform(647.9,484.15);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween36("synched",0);
	this.instance_11.setTransform(568.3,574.55);
	this.instance_11._off = true;

	this.instance_12 = new lib.Tween37("synched",0);
	this.instance_12.setTransform(490.5,624.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},39).to({state:[{t:this.instance_7}]},50).to({state:[{t:this.instance_8}]},60).to({state:[{t:this.instance_9}]},42).to({state:[{t:this.instance_9}]},19).to({state:[{t:this.instance_10}]},23).to({state:[{t:this.instance_11}]},35).to({state:[{t:this.instance_12}]},31).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true,x:277.75,y:461.75},39).wait(261));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:false},39).to({_off:true,x:363.6,y:425.4},50).wait(211));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(39).to({_off:false},50).to({_off:true,x:499.6,y:402.8},60).wait(151));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(89).to({_off:false},60).to({_off:true,x:587.6,y:416.4},42).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(149).to({_off:false},42).to({x:614.9,y:431.05},19).to({_off:true,x:647.9,y:484.15},23).wait(67));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(210).to({_off:false},23).to({_off:true,x:568.3,y:574.55},35).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(233).to({_off:false},35).to({_off:true,x:490.5,y:624.9},31).wait(1));

	// 圖層_50
	this.instance_13 = new lib.Tween24("synched",0);
	this.instance_13.setTransform(384.85,547.85);

	this.instance_14 = new lib.Tween25("synched",0);
	this.instance_14.setTransform(384.85,547.85);
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween26("synched",0);
	this.instance_15.setTransform(384.85,547.85);
	this.instance_15._off = true;

	this.instance_16 = new lib.Tween27("synched",0);
	this.instance_16.setTransform(384.85,547.85);
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween28("synched",0);
	this.instance_17.setTransform(384.8,547.85);
	this.instance_17._off = true;

	this.instance_18 = new lib.Tween29("synched",0);
	this.instance_18.setTransform(384.85,547.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_13}]}).to({state:[{t:this.instance_14}]},46).to({state:[{t:this.instance_15}]},52).to({state:[{t:this.instance_16}]},65).to({state:[{t:this.instance_17}]},63).to({state:[{t:this.instance_18}]},73).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({_off:true},46).wait(254));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:false},46).to({_off:true},52).wait(202));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(46).to({_off:false},52).to({_off:true},65).wait(137));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(98).to({_off:false},65).to({_off:true,x:384.8},63).wait(74));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(163).to({_off:false},63).to({_off:true,x:384.85},73).wait(1));

	// 圖層_49
	this.instance_19 = new lib.CachedBmp_5();
	this.instance_19.setTransform(679.45,384.7,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_6();
	this.instance_20.setTransform(617.35,357,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_19}]}).to({state:[{t:this.instance_20}]},299).wait(1));

	// 圖層_48
	this.instance_21 = new lib.Tween18("synched",0);
	this.instance_21.setTransform(605.35,341.85);

	this.instance_22 = new lib.Tween19("synched",0);
	this.instance_22.setTransform(461.3,344.45);
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween20("synched",0);
	this.instance_23.setTransform(244.15,413.2);
	this.instance_23._off = true;

	this.instance_24 = new lib.Tween21("synched",0);
	this.instance_24.setTransform(38.75,546.1);
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween22("synched",0);
	this.instance_25.setTransform(-143.85,889);
	this.instance_25._off = true;

	this.instance_26 = new lib.Tween23("synched",0);
	this.instance_26.setTransform(321.6,887.15,1,1,-8.4471,0,0,2,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21}]}).to({state:[{t:this.instance_22}]},59).to({state:[{t:this.instance_23}]},60).to({state:[{t:this.instance_24}]},60).to({state:[{t:this.instance_25}]},90).to({state:[{t:this.instance_26}]},30).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({_off:true,x:461.3,y:344.45},59).wait(241));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({_off:false},59).to({_off:true,x:244.15,y:413.2},60).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(59).to({_off:false},60).to({_off:true,x:38.75,y:546.1},60).wait(121));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(119).to({_off:false},60).to({_off:true,x:-143.85,y:889},90).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(179).to({_off:false},90).to({_off:true,regX:2,regY:10,rotation:-8.4471,x:321.6,y:887.15},30).wait(1));

	// 圖層_46
	this.instance_27 = new lib.Path_18();
	this.instance_27.setTransform(502.7,448.6,5.9045,6.0669,0,0,0,2.1,2.1);
	this.instance_27.compositeOperation = "screen";

	this.instance_28 = new lib.Group_5();
	this.instance_28.setTransform(505.1,448,5.9045,6.0669,0,0,0,1.8,2);
	this.instance_28.alpha = 0.1602;
	this.instance_28.compositeOperation = "multiply";

	this.instance_29 = new lib.Group_1_2();
	this.instance_29.setTransform(502.1,448.6,5.9045,6.0669,0,0,0,2,2.1);
	this.instance_29.alpha = 0.6797;
	this.instance_29.compositeOperation = "multiply";

	this.instance_30 = new lib.CachedBmp_7();
	this.instance_30.setTransform(490.85,436.5,0.5,0.5);

	this.instance_31 = new lib.Path_3_1();
	this.instance_31.setTransform(502.4,448.6,5.9045,6.0669,0,0,0,2.2,2.2);
	this.instance_31.compositeOperation = "screen";

	this.instance_32 = new lib.CachedBmp_8();
	this.instance_32.setTransform(490.85,436.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27}]}).to({state:[{t:this.instance_31},{t:this.instance_32},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27}]},299).wait(1));

	// 圖層_45
	this.instance_33 = new lib.Tween12("synched",0);
	this.instance_33.setTransform(391.6,305.8);

	this.instance_34 = new lib.Tween13("synched",0);
	this.instance_34.setTransform(515.55,277.25);
	this.instance_34._off = true;

	this.instance_35 = new lib.Tween14("synched",0);
	this.instance_35.setTransform(659.55,258.45);
	this.instance_35._off = true;

	this.instance_36 = new lib.Tween15("synched",0);
	this.instance_36.setTransform(850,327.75);
	this.instance_36._off = true;

	this.instance_37 = new lib.Tween16("synched",0);
	this.instance_37.setTransform(867.95,444.7,1,1,-14.7161);
	this.instance_37._off = true;

	this.instance_38 = new lib.Tween17("synched",0);
	this.instance_38.setTransform(738.85,614.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_33}]}).to({state:[{t:this.instance_34}]},33).to({state:[{t:this.instance_35}]},65).to({state:[{t:this.instance_36}]},61).to({state:[{t:this.instance_37}]},65).to({state:[{t:this.instance_38}]},75).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_33).to({_off:true,x:515.55,y:277.25},33).wait(267));
	this.timeline.addTween(cjs.Tween.get(this.instance_34).to({_off:false},33).to({_off:true,x:659.55,y:258.45},65).wait(202));
	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(33).to({_off:false},65).to({_off:true,x:850,y:327.75},61).wait(141));
	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(98).to({_off:false},61).to({_off:true,rotation:-14.7161,x:867.95,y:444.7},65).wait(76));
	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(159).to({_off:false},65).to({_off:true,rotation:0,x:738.85,y:614.2},75).wait(1));

	// 圖層_43
	this.instance_39 = new lib.Tween1("synched",0);
	this.instance_39.setTransform(775.45,648.45);

	this.instance_40 = new lib.Tween2("synched",0);
	this.instance_40.setTransform(913.25,542.2);
	this.instance_40._off = true;

	this.instance_41 = new lib.Tween3("synched",0);
	this.instance_41.setTransform(942.45,285.7);
	this.instance_41._off = true;

	this.instance_42 = new lib.Tween4("synched",0);
	this.instance_42.setTransform(756.2,205.65);
	this.instance_42._off = true;

	this.instance_43 = new lib.Tween5("synched",0);
	this.instance_43.setTransform(408.65,250.45);
	this.instance_43._off = true;

	this.instance_44 = new lib.Tween6("synched",0);
	this.instance_44.setTransform(143.9,333.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_39}]}).to({state:[{t:this.instance_40}]},59).to({state:[{t:this.instance_41}]},60).to({state:[{t:this.instance_42}]},59).to({state:[{t:this.instance_43}]},61).to({state:[{t:this.instance_44}]},60).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_39).to({_off:true,x:913.25,y:542.2},59).wait(241));
	this.timeline.addTween(cjs.Tween.get(this.instance_40).to({_off:false},59).to({_off:true,x:942.45,y:285.7},60).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(59).to({_off:false},60).to({_off:true,x:756.2,y:205.65},59).wait(122));
	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(119).to({_off:false},59).to({_off:true,x:408.65,y:250.45},61).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(178).to({_off:false},61).to({_off:true,x:143.9,y:333.1},60).wait(1));

	// 圖層_44
	this.instance_45 = new lib.Tween7("synched",0);
	this.instance_45.setTransform(863.5,496.2);

	this.instance_46 = new lib.Tween8("synched",0);
	this.instance_46.setTransform(682.1,647);
	this.instance_46._off = true;

	this.instance_47 = new lib.Tween9("synched",0);
	this.instance_47.setTransform(352.8,822.45);
	this.instance_47._off = true;

	this.instance_48 = new lib.Tween10("synched",0);
	this.instance_48.setTransform(-12.7,487.9);
	this.instance_48._off = true;

	this.instance_49 = new lib.Tween11("synched",0);
	this.instance_49.setTransform(63.1,443.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_45}]}).to({state:[{t:this.instance_46}]},44).to({state:[{t:this.instance_47}]},45).to({state:[{t:this.instance_47}]},80).to({state:[{t:this.instance_48}]},81).to({state:[{t:this.instance_49}]},49).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_45).to({_off:true,x:682.1,y:647},44).wait(256));
	this.timeline.addTween(cjs.Tween.get(this.instance_46).to({_off:false},44).to({_off:true,x:352.8,y:822.45},45).wait(211));
	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(44).to({_off:false},45).to({regX:-10,regY:2,x:-110.95,y:841.1},80).to({_off:true,regX:0,regY:0,x:-12.7,y:487.9},81).wait(50));
	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(169).to({_off:false},81).to({_off:true,x:63.1,y:443.65},49).wait(1));

	// Layer_5
	this.instance_50 = new lib.CachedBmp_14();
	this.instance_50.setTransform(49.85,602.15,0.5,0.5);

	this.instance_51 = new lib.Path_13_1();
	this.instance_51.setTransform(614.95,542.05,5.9056,6.068,0,0,0,0.6,0.6);
	this.instance_51.alpha = 0.8008;

	this.instance_52 = new lib.Path_12_1();
	this.instance_52.setTransform(614.9,542.05,5.9056,6.068,0,0,0,1,1);
	this.instance_52.alpha = 0.1992;

	this.instance_53 = new lib.Path_11_1();
	this.instance_53.setTransform(350,659.5,5.9056,6.068,0,0,0,1.2,1.2);
	this.instance_53.alpha = 0.8008;

	this.instance_54 = new lib.Path_10_1();
	this.instance_54.setTransform(349.45,658.9,5.9056,6.068,0,0,0,1.8,1.9);
	this.instance_54.alpha = 0.1992;

	this.instance_55 = new lib.Path_9_1();
	this.instance_55.setTransform(218,316.6,5.9056,6.068,0,0,0,0.5,0.5);
	this.instance_55.alpha = 0.8008;
	this.instance_55.compositeOperation = "screen";

	this.instance_56 = new lib.Path_8_1();
	this.instance_56.setTransform(218,316.25,5.9056,6.068,0,0,0,1.1,1.1);
	this.instance_56.alpha = 0.1992;

	this.instance_57 = new lib.Path_7_1();
	this.instance_57.setTransform(218.3,316.25,5.9056,6.068,0,0,0,1.6,1.5);
	this.instance_57.alpha = 0.1211;

	this.instance_58 = new lib.Path_6_1();
	this.instance_58.setTransform(752.55,514.75,5.9056,6.068,0,0,0,0.7,0.6);
	this.instance_58.alpha = 0.8008;
	this.instance_58.compositeOperation = "screen";

	this.instance_59 = new lib.Path_5_1();
	this.instance_59.setTransform(752.25,514.75,5.9056,6.068,0,0,0,1.5,1.4);
	this.instance_59.alpha = 0.1992;

	this.instance_60 = new lib.Path_4_1();
	this.instance_60.setTransform(752.25,514.75,5.9056,6.068,0,0,0,2,1.9);
	this.instance_60.alpha = 0.1211;

	this.instance_61 = new lib.Path_3_3();
	this.instance_61.setTransform(60,528.1,5.9056,6.068,0,0,0,0.6,0.5);
	this.instance_61.compositeOperation = "screen";

	this.instance_62 = new lib.CachedBmp_13();
	this.instance_62.setTransform(334.9,727,0.5,0.5);

	this.instance_63 = new lib.Path_2_4();
	this.instance_63.setTransform(336.7,728.95,5.9056,6.068,0,0,0,1.1,1.1);
	this.instance_63.alpha = 0.1992;

	this.instance_64 = new lib.CachedBmp_12();
	this.instance_64.setTransform(767.45,286.8,0.5,0.5);

	this.instance_65 = new lib.Path_0_4();
	this.instance_65.setTransform(771.75,290.45,5.9056,6.068,0,0,0,2.6,2.4);
	this.instance_65.alpha = 0.1992;

	this.instance_66 = new lib.CachedBmp_11();
	this.instance_66.setTransform(63.5,444.55,0.5,0.5);

	this.instance_67 = new lib.Path_22();
	this.instance_67.setTransform(65.3,446.5,5.9056,6.068,0,0,0,1.2,1.2);
	this.instance_67.alpha = 0.1992;

	this.instance_68 = new lib.CachedBmp_16();
	this.instance_68.setTransform(982.55,428.75,0.5,0.5);

	this.instance_69 = new lib.Path_1_6();
	this.instance_69.setTransform(985.6,431.55,5.9045,6.0669,0,0,0,2.6,2.5);
	this.instance_69.alpha = 0.1992;

	this.instance_70 = new lib.CachedBmp_9();
	this.instance_70.setTransform(46.8,515.1,0.5,0.5);

	this.instance_71 = new lib.Group_2_1();
	this.instance_71.setTransform(499.25,491.25,5.9045,6.0669,0,0,0,84.1,45.4);
	this.instance_71.alpha = 0.3984;

	this.instance_72 = new lib.Group_1_3();
	this.instance_72.setTransform(445.55,518.55,5.9045,6.0669,0,0,0,75,40.7);
	this.instance_72.alpha = 0.3984;

	this.instance_73 = new lib.Group_0();
	this.instance_73.setTransform(391.2,545.95,5.9045,6.0669,0,0,0,65.8,35.6);
	this.instance_73.alpha = 0.3984;

	this.instance_74 = new lib.Group_6();
	this.instance_74.setTransform(386.25,545.95,5.9045,6.0669,0,0,0,44.1,23.3);
	this.instance_74.alpha = 0.3984;

	this.instance_75 = new lib.CachedBmp_20();
	this.instance_75.setTransform(49.85,602.15,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_19();
	this.instance_76.setTransform(334.9,727,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_18();
	this.instance_77.setTransform(767.45,286.8,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_17();
	this.instance_78.setTransform(63.5,444.55,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_15();
	this.instance_79.setTransform(46.8,515.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50}]}).to({state:[{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_79},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_78},{t:this.instance_65},{t:this.instance_77},{t:this.instance_63},{t:this.instance_76},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_75}]},299).wait(1));

	// Layer_2
	this.instance_80 = new lib.CachedBmp_21();
	this.instance_80.setTransform(10.05,81.4,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_22();
	this.instance_81.setTransform(10.05,81.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_80}]}).to({state:[{t:this.instance_81}]},299).wait(1));

	// Layer_3
	this.instance_82 = new lib.Mesh();
	this.instance_82.setTransform(-9,-5,5.743,7.5172);

	this.timeline.addTween(cjs.Tween.get(this.instance_82).wait(300));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EhRjg9jMCjHAAAMAAAB7HMijHAAAg");
	this.shape.setTransform(512,384);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhRjA9kMAAAh7HMCjHAAAMAAAB7Hg");
	this.shape_1.setTransform(512,384);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(300));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(294.2,373,778.7,574.8);
// library properties:
lib.properties = {
	id: '49458D9D2E0848CA8716D52A38D4534D',
	width: 1024,
	height: 768,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_22.png?1655284599555", id:"CachedBmp_22"},
		{src:"images/CachedBmp_21.png?1655284599555", id:"CachedBmp_21"},
		{src:"images/TryTrySee.png?1655284599555", id:"TryTrySee"},
		{src:"images/Untitled_1_atlas_1.png?1655284599271", id:"Untitled_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['49458D9D2E0848CA8716D52A38D4534D'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;